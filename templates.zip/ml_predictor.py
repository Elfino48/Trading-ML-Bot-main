import logging
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import TimeSeriesSplit, RandomizedSearchCV
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.feature_selection import SelectKBest, f_classif, RFE
from sklearn.covariance import EllipticEnvelope
from sklearn.decomposition import PCA
from sklearn.linear_model import LassoCV
import joblib
import warnings
import os
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
import sklearn
from scipy import stats
from scipy.stats import randint, uniform

warnings.filterwarnings('ignore')

class MLPredictor:
    def __init__(self, error_handler=None, database=None):
        self.models = {}
        self.previous_models = {}
        self.scalers = {}
        self.previous_scalers = {}
        self.feature_selectors = {}
        self.feature_columns = []
        self.error_handler = error_handler
        self.database = database
        self.model_performance = {}
        self.performance_threshold = 0.55
        self.feature_importance = {}
        self.walk_forward_performance = {}
        self.model_versions = {}
        self.performance_history = {}
        self.prediction_quality_metrics = {}
        self.feature_drift_detector = {}
        self.real_time_monitor = {}
        self.logger = logging.getLogger('MLPredictor')

        self.auto_save_interval = 1
        self.training_count = 0
        
        self.quality_metrics_window = 100
        self.drift_threshold = 0.15
        self.performance_alert_threshold = 0.1
        self.ensemble_weight_current = 0.8
        self.ensemble_weight_previous = 0.2
        
        self.max_features = 25
        self.feature_selection_method = 'importance'
        self.use_pca = False
        self.pca_components = 15
        
        self.walk_forward_splits = 5
        self.validation_window = 200
        self.min_training_samples = 150
        
        self.target_configs = [
            {'periods': 5, 'weight': 0.4, 'threshold_multiplier': 1.5},
            {'periods': 10, 'weight': 0.3, 'threshold_multiplier': 2.0},
            {'periods': 20, 'weight': 0.3, 'threshold_multiplier': 2.5}
        ]
        
        self.rf_param_dist = {
            'n_estimators': randint(50, 200),
            'max_depth': randint(3, 15),
            'min_samples_split': randint(2, 20),
            'min_samples_leaf': randint(1, 10),
            'max_features': ['sqrt', 'log2', None],
            'bootstrap': [True, False]
        }
        
        self.gb_param_dist = {
            'n_estimators': randint(50, 150),
            'learning_rate': uniform(0.01, 0.2),
            'max_depth': randint(3, 10),
            'min_samples_split': randint(2, 20),
            'min_samples_leaf': randint(1, 10),
            'subsample': uniform(0.6, 0.4)
        }
        
        self.rf_params = {
            'n_estimators': 100,
            'max_depth': 8,
            'min_samples_split': 15,
            'min_samples_leaf': 8,
            'max_features': 'sqrt',
            'random_state': 42,
            'n_jobs': -1
        }
        
        self.gb_params = {
            'n_estimators': 80,
            'max_depth': 5,
            'learning_rate': 0.1,
            'min_samples_split': 15,
            'min_samples_leaf': 8,
            'subsample': 0.8,
            'random_state': 42
        }
        
        self.enable_hyperparameter_optimization = True
        self.hpo_n_iter = 20
        self.hpo_cv = 3
        
        self.fixed_feature_set = [
            'returns_1', 'returns_3', 'returns_5', 'returns_10', 'returns_20',
            'volatility_5', 'volatility_10', 'volatility_20',
            'volume_ma_ratio_5', 'volume_ma_ratio_10', 'volume_ma_ratio_20',
            'volume_volatility', 'high_low_ratio', 'close_open_ratio', 'body_size',
            'sma_ratio_5_20', 'sma_ratio_10_50', 'sma_ratio_20_100',
            'rsi_6', 'rsi_14', 'rsi_21',
            'momentum_5', 'momentum_10', 'momentum_20',
            'price_vs_high_20', 'price_vs_high_50', 'price_vs_low_20', 'price_vs_low_50',
            'atr_14', 'atr_ratio',
            'bb_position_20', 'bb_position_50',
            'macd', 'macd_signal', 'macd_histogram',
            'market_regime_feature', 'volatility_regime_feature',
            'weekday_effect', 'hour_effect',
            'price_efficiency', 'hurst_exponent',
            'market_micro_1', 'market_micro_2'
        ]
        
        print(f"🤖 Enhanced ML Predictor initialized with scikit-learn {sklearn.__version__}")

    def set_error_handler(self, error_handler):
        self.error_handler = error_handler

    def set_database(self, database):
        self.database = database

    def prepare_features_point_in_time(self, df: pd.DataFrame, current_idx: int, lookback: int = 50) -> pd.DataFrame:
        if current_idx < lookback:
            return pd.DataFrame()

        features = {}
        current_data = df.iloc[:current_idx+1]
        
        close_prices = current_data['close'].astype(float)
        high_prices = current_data['high'].astype(float)
        low_prices = current_data['low'].astype(float)
        volume = current_data['volume'].astype(float)
        opens = current_data['open'].astype(float)

        try:
            for period in [1, 3, 5, 10, 20]:
                if len(close_prices) > period:
                    features[f'returns_{period}'] = close_prices.iloc[-1] / close_prices.iloc[-period-1] - 1
                else:
                    features[f'returns_{period}'] = 0.0
            
            for period in [5, 10, 20]:
                if len(close_prices) > period:
                    features[f'volatility_{period}'] = close_prices.pct_change().rolling(period).std().iloc[-1]
                else:
                    features[f'volatility_{period}'] = 0.02
            
            for period in [5, 10, 20]:
                if len(volume) > period:
                    features[f'volume_ma_ratio_{period}'] = volume.iloc[-1] / volume.rolling(period).mean().iloc[-1]
                else:
                    features[f'volume_ma_ratio_{period}'] = 1.0
            
            if len(volume) > 20:
                features['volume_volatility'] = volume.pct_change().rolling(20).std().iloc[-1]
            else:
                features['volume_volatility'] = 0.0
            
            features['high_low_ratio'] = (high_prices.iloc[-1] - low_prices.iloc[-1]) / close_prices.iloc[-1]
            features['close_open_ratio'] = (close_prices.iloc[-1] - opens.iloc[-1]) / opens.iloc[-1]
            features['body_size'] = abs(opens.iloc[-1] - close_prices.iloc[-1]) / (high_prices.iloc[-1] - low_prices.iloc[-1]) if (high_prices.iloc[-1] - low_prices.iloc[-1]) > 0 else 0
            
            for short_period, long_period in [(5, 20), (10, 50), (20, 100)]:
                if len(close_prices) > long_period:
                    sma_short = close_prices.rolling(short_period).mean().iloc[-1]
                    sma_long = close_prices.rolling(long_period).mean().iloc[-1]
                    features[f'sma_ratio_{short_period}_{long_period}'] = sma_short / sma_long - 1
                else:
                    features[f'sma_ratio_{short_period}_{long_period}'] = 0.0
            
            for period in [6, 14, 21]:
                features[f'rsi_{period}'] = self._calculate_rsi_point_in_time(close_prices, period)
            
            for period in [5, 10, 20]:
                if len(close_prices) > period:
                    features[f'momentum_{period}'] = close_prices.iloc[-1] / close_prices.iloc[-period-1] - 1
                else:
                    features[f'momentum_{period}'] = 0.0
            
            for period in [20, 50]:
                if len(close_prices) > period:
                    features[f'price_vs_high_{period}'] = close_prices.iloc[-1] / high_prices.rolling(period).max().iloc[-1]
                    features[f'price_vs_low_{period}'] = close_prices.iloc[-1] / low_prices.rolling(period).min().iloc[-1]
                else:
                    features[f'price_vs_high_{period}'] = 1.0
                    features[f'price_vs_low_{period}'] = 1.0
            
            features['atr_14'] = self._calculate_atr_point_in_time(high_prices, low_prices, close_prices, 14)
            features['atr_ratio'] = features['atr_14'] / close_prices.iloc[-1]
            
            for period, std in [(20, 2), (50, 2)]:
                if len(close_prices) > period:
                    bb_upper, bb_middle, bb_lower = self._calculate_bollinger_bands_point_in_time(close_prices, period, std)
                    features[f'bb_position_{period}'] = (close_prices.iloc[-1] - bb_lower) / (bb_upper - bb_lower) if (bb_upper - bb_lower) > 0 else 0.5
                else:
                    features[f'bb_position_{period}'] = 0.5
            
            features['macd'], features['macd_signal'] = self._calculate_macd_point_in_time(close_prices)
            features['macd_histogram'] = features['macd'] - features['macd_signal']
            
            features['market_regime_feature'] = self._calculate_market_regime_feature(close_prices, high_prices, low_prices)
            features['volatility_regime_feature'] = self._calculate_volatility_regime_feature(close_prices)
            
            if hasattr(current_data.index[-1], 'weekday'):
                features['weekday_effect'] = current_data.index[-1].weekday()
                features['hour_effect'] = current_data.index[-1].hour
            else:
                features['weekday_effect'] = 0
                features['hour_effect'] = 12
            
            features['price_efficiency'] = self._calculate_price_efficiency(close_prices)
            features['hurst_exponent'] = self._calculate_hurst_exponent(close_prices.tail(min(100, len(close_prices))))
                
            features['market_micro_1'] = self._calculate_market_microstructure_1(high_prices, low_prices, close_prices, volume)
            features['market_micro_2'] = self._calculate_market_microstructure_2(high_prices, low_prices, close_prices, volume)
            
            features_df = pd.DataFrame([features])
            
            for feature in self.fixed_feature_set:
                if feature not in features_df.columns:
                    features_df[feature] = 0.0
            
            return features_df[self.fixed_feature_set]
            
        except Exception as e:
            if self.error_handler:
                self.error_handler.handle_ml_error(e, "ALL", "feature_preparation")
            return pd.DataFrame()

    def create_multi_timeframe_targets(self, df: pd.DataFrame, current_idx: int) -> List[int]:
        targets = []
        
        for config in self.target_configs:
            periods = config['periods']
            threshold_multiplier = config['threshold_multiplier']
            
            if current_idx + periods >= len(df):
                targets.append(0)
                continue
                
            current_price = df['close'].iloc[current_idx]
            future_price = df['close'].iloc[current_idx + periods]
            future_return = (future_price - current_price) / current_price
            
            volatility = df['close'].pct_change().rolling(20).std().iloc[current_idx]
            threshold = max(0.015, volatility * threshold_multiplier)
            
            if future_return > threshold:
                targets.append(1)
            elif future_return < -threshold:
                targets.append(-1)
            else:
                targets.append(0)
        
        return targets

    def create_enhanced_target(self, df: pd.DataFrame, current_idx: int) -> int:
        multi_targets = self.create_multi_timeframe_targets(df, current_idx)
        
        if not multi_targets:
            return 0
        
        weighted_vote = 0
        total_weight = 0
        
        for i, target in enumerate(multi_targets):
            weight = self.target_configs[i]['weight']
            weighted_vote += target * weight
            total_weight += weight
        
        if weighted_vote > 0.3:
            return 2
        elif weighted_vote > 0.1:
            return 1
        elif weighted_vote < -0.3:
            return -2
        elif weighted_vote < -0.1:
            return -1
        else:
            return 0

    def prepare_training_data_enhanced(self, df: pd.DataFrame, min_samples: int = None) -> tuple:
            if min_samples is None:
                min_samples = self.min_training_samples

            max_bars = min(2000, len(df) - 50)
            if max_bars < min_samples + 50:
                return pd.DataFrame(), pd.Series()

            df = df.tail(max_bars)

            features_list = []
            targets = []

            stride = max(1, len(df) // 500)
            max_target_period = max([c['periods'] for c in self.target_configs])

            start_idx = 50
            end_idx = len(df) - max_target_period
            if start_idx >= end_idx:
                return pd.DataFrame(), pd.Series()

            for i in range(start_idx, end_idx, stride):
                features = self.prepare_features_point_in_time(df, i)
                target = self.create_enhanced_target(df, i)

                if not features.empty:
                    features_list.append(features.iloc[0])
                    targets.append(target)

            if len(features_list) < min_samples:
                return pd.DataFrame(), pd.Series()

            features_df = pd.DataFrame(features_list).fillna(0)
            target_series = pd.Series(targets, index=features_df.index)

            features_df = self._clean_features(features_df)
            return features_df, target_series

    def _clean_features(self, features_df: pd.DataFrame) -> pd.DataFrame:
        constant_features = features_df.columns[features_df.std() == 0]
        if len(constant_features) > 0:
            features_df = features_df.drop(columns=constant_features)
        
        corr_matrix = features_df.corr().abs()
        upper_tri = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
        to_drop = [column for column in upper_tri.columns if any(upper_tri[column] > 0.95)]
        
        if len(to_drop) > 0:
            features_df = features_df.drop(columns=to_drop)
        
        return features_df

    def _optimize_hyperparameters(self, X_train: np.ndarray, y_train: pd.Series) -> Tuple[dict, dict]:
        if not self.enable_hyperparameter_optimization:
            return self.rf_params, self.gb_params
        
        try:
            tscv = TimeSeriesSplit(n_splits=self.hpo_cv)
            
            rf_search = RandomizedSearchCV(
                RandomForestClassifier(random_state=42),
                self.rf_param_dist,
                n_iter=self.hpo_n_iter,
                cv=tscv,
                scoring='accuracy',
                random_state=42,
                n_jobs=-1
            )
            
            rf_search.fit(X_train, y_train)
            best_rf_params = rf_search.best_params_
            
            gb_search = RandomizedSearchCV(
                GradientBoostingClassifier(random_state=42),
                self.gb_param_dist,
                n_iter=self.hpo_n_iter,
                cv=tscv,
                scoring='accuracy',
                random_state=42
            )
            
            gb_search.fit(X_train, y_train)
            best_gb_params = gb_search.best_params_
            
            return best_rf_params, best_gb_params
            
        except Exception as e:
            return self.rf_params, self.gb_params

    def train_model(self, symbol: str, df: pd.DataFrame) -> bool:
        try:
            training_start = datetime.now()
            
            if symbol in self.models:
                self.previous_models[symbol] = {
                    'rf': self.models[symbol]['rf'],
                    'gb': self.models[symbol]['gb'],
                    'feature_set': self.feature_importance.get(symbol, {}).get('selected_features', [])
                }
                self.previous_scalers[symbol] = self.scalers[symbol]
            
            features, target = self.prepare_training_data_enhanced(df)
            
            if features.empty or target.empty:
                self._record_training_failure(symbol, "insufficient_data")
                return False
                
            if symbol not in self.feature_importance:
                self.feature_importance[symbol] = {}
                
            features_selected, selected_features = self._select_features(features, target, symbol)
            self.feature_importance[symbol]['selected_features'] = selected_features
            
            X_train, X_test, y_train, y_test = self.time_series_train_test_split(features_selected, target)
            
            if X_train is None:
                self._record_training_failure(symbol, "split_failed")
                return False

            scaler = StandardScaler()
            X_train_scaled = scaler.fit_transform(X_train)
            X_test_scaled = scaler.transform(X_test)
            
            if self.use_pca:
                X_train_scaled, X_test_scaled = self._apply_pca(X_train_scaled, X_test_scaled)

            rf_params, gb_params = self._optimize_hyperparameters(X_train_scaled, y_train)
            
            rf = RandomForestClassifier(**rf_params)
            gb = GradientBoostingClassifier(**gb_params)

            rf.fit(X_train_scaled, y_train)
            gb.fit(X_train_scaled, y_train)

            rf_pred = rf.predict(X_test_scaled)
            gb_pred = gb.predict(X_test_scaled)

            rf_accuracy = accuracy_score(y_test, rf_pred)
            gb_accuracy = accuracy_score(y_test, gb_pred)
            
            rf_precision = precision_score(y_test, rf_pred, average='weighted', zero_division=0)
            gb_precision = precision_score(y_test, gb_pred, average='weighted', zero_division=0)
            
            rf_recall = recall_score(y_test, rf_pred, average='weighted', zero_division=0)
            gb_recall = recall_score(y_test, gb_pred, average='weighted', zero_division=0)
            
            rf_f1 = f1_score(y_test, rf_pred, average='weighted', zero_division=0)
            gb_f1 = f1_score(y_test, gb_pred, average='weighted', zero_division=0)

            rf_train_pred = rf.predict(X_train_scaled)
            rf_train_accuracy = accuracy_score(y_train, rf_train_pred)
            rf_overfit = rf_train_accuracy - rf_accuracy
            
            gb_train_pred = gb.predict(X_train_scaled)
            gb_train_accuracy = accuracy_score(y_train, gb_train_pred)
            gb_overfit = gb_train_accuracy - gb_accuracy
            
            if not hasattr(self, 'models'):
                self.models = {}
            if not hasattr(self, 'scalers'):
                self.scalers = {}
                
            self.models[symbol] = {'rf': rf, 'gb': gb}
            self.scalers[symbol] = scaler
            
            if not hasattr(self, 'feature_importance'):
                self.feature_importance = {}
                
            self.feature_importance[symbol].update({
                'features': selected_features,
                'rf_importance': rf.feature_importances_.tolist(),
                'gb_importance': gb.feature_importances_.tolist(),
                'rf_overfit': rf_overfit,
                'gb_overfit': gb_overfit,
                'rf_params': rf_params,
                'gb_params': gb_params
            })
            
            self._initialize_feature_drift_detector(symbol, X_train_scaled)
            self._initialize_prediction_quality_tracking(symbol)

            model_version = f"v{datetime.now().strftime('%Y%m%d_%H%M')}"
            training_duration = (datetime.now() - training_start).total_seconds()
            
            ensemble_accuracy = (rf_accuracy + gb_accuracy) / 2
            
            self.model_versions[symbol] = {
                'version': model_version,
                'training_date': datetime.now(),
                'accuracy': ensemble_accuracy,
                'rf_accuracy': rf_accuracy,
                'gb_accuracy': gb_accuracy,
                'rf_precision': rf_precision,
                'gb_precision': gb_precision,
                'rf_recall': rf_recall,
                'gb_recall': gb_recall,
                'rf_f1': rf_f1,
                'gb_f1': gb_f1,
                'training_samples': len(X_train),
                'test_samples': len(X_test),
                'training_duration_seconds': training_duration,
                'status': 'trained',
                'training_bars_used': len(df),
                'feature_count': len(selected_features),
                'overfit_scores': {'rf': rf_overfit, 'gb': gb_overfit},
                'feature_selection_method': self.feature_selection_method,
                'target_type': 'multi_timeframe_enhanced',
                'hyperparameters_optimized': self.enable_hyperparameter_optimization
            }

            if self.database:
                self._store_training_results(symbol, model_version, training_duration, 
                                        rf_accuracy, gb_accuracy, rf_precision, gb_precision,
                                        rf_recall, gb_recall, rf_f1, gb_f1,
                                        len(X_train), len(X_test), len(df), selected_features,
                                        rf_params, gb_params)

            if symbol not in self.performance_history:
                self.performance_history[symbol] = []
            
            training_record = {
                'timestamp': datetime.now(),
                'accuracy': ensemble_accuracy,
                'rf_accuracy': rf_accuracy,
                'gb_accuracy': gb_accuracy,
                'training_samples': len(X_train),
                'feature_count': len(selected_features),
                'model_version': model_version,
                'training_duration_seconds': training_duration
            }
            
            self.performance_history[symbol].append(training_record)
            
            if len(self.performance_history[symbol]) > 50:
                self.performance_history[symbol] = self.performance_history[symbol][-50:]
            
            self.training_count += 1
            self.save_models()
            
            try:
                wf_result = self.walk_forward_validation_enhanced(symbol, df)
            except Exception as wf_error:
                pass
            
            return True
        
        except Exception as e:
            if self.error_handler:
                self.error_handler.handle_ml_error(e, symbol, "training")
            
            self._record_training_failure(symbol, f"error: {str(e)[:100]}")
            return False

    def walk_forward_validation_enhanced(self, symbol: str, df: pd.DataFrame, n_splits: int = None) -> Dict:
        if n_splits is None:
            n_splits = self.walk_forward_splits
            
        try:
            features, target = self.prepare_training_data_enhanced(df)
            
            if features.empty or target.empty:
                return {'success': False, 'reason': 'Insufficient data'}

            tscv = TimeSeriesSplit(n_splits=n_splits, test_size=50, gap=10)
            performances = []
            feature_importances = []
            
            for fold, (train_idx, test_idx) in enumerate(tscv.split(features)):
                if len(train_idx) < 50 or len(test_idx) < 10:
                    continue
                    
                X_train, X_test = features.iloc[train_idx], features.iloc[test_idx]
                y_train, y_test = target.iloc[train_idx], target.iloc[test_idx]

                X_train_selected, selected_features = self._select_features(X_train, y_train, f"{symbol}_fold_{fold}")
                X_test_selected = X_test[selected_features]

                scaler = StandardScaler()
                X_train_scaled = scaler.fit_transform(X_train_selected)
                X_test_scaled = scaler.transform(X_test_selected)

                model = RandomForestClassifier(**self.rf_params)
                model.fit(X_train_scaled, y_train)

                pred = model.predict(X_test_scaled)
                pred_proba = model.predict_proba(X_test_scaled)
                
                accuracy = accuracy_score(y_test, pred)
                precision = precision_score(y_test, pred, average='weighted', zero_division=0)
                recall = recall_score(y_test, pred, average='weighted', zero_division=0)
                f1 = f1_score(y_test, pred, average='weighted', zero_division=0)
                
                confidence = np.max(pred_proba, axis=1).mean()
                balanced_accuracy = self._calculate_balanced_accuracy(y_test, pred)
                
                unique, counts = np.unique(y_test, return_counts=True)
                class_distribution = dict(zip(unique, counts))
                
                performances.append({
                    'accuracy': accuracy,
                    'precision': precision,
                    'recall': recall,
                    'f1': f1,
                    'confidence': confidence,
                    'balanced_accuracy': balanced_accuracy,
                    'fold_size': len(test_idx),
                    'class_distribution': class_distribution
                })
                
                feature_importances.append(model.feature_importances_)

            if performances:
                accuracies = [p['accuracy'] for p in performances]
                f1_scores = [p['f1'] for p in performances]
                confidences = [p['confidence'] for p in performances]
                
                result = {
                    'success': True,
                    'avg_accuracy': np.mean(accuracies),
                    'avg_precision': np.mean([p['precision'] for p in performances]),
                    'avg_recall': np.mean([p['recall'] for p in performances]),
                    'avg_f1': np.mean(f1_scores),
                    'avg_confidence': np.mean(confidences),
                    'std_accuracy': np.std(accuracies),
                    'std_f1': np.std(f1_scores),
                    'min_accuracy': np.min(accuracies),
                    'max_accuracy': np.max(accuracies),
                    'consistency_score': 1 - (np.std(accuracies) / np.mean(accuracies)) if np.mean(accuracies) > 0 else 0,
                    'n_successful_folds': len(performances),
                    'fold_details': performances
                }
                
                self.walk_forward_performance[symbol] = result
                
                if self.database:
                    self.database.store_system_event(
                        "WALK_FORWARD_VALIDATION_ENHANCED",
                        {
                            'symbol': symbol,
                            'avg_accuracy': result['avg_accuracy'],
                            'avg_precision': result['avg_precision'],
                            'avg_recall': result['avg_recall'],
                            'avg_f1': result['avg_f1'],
                            'n_folds': result['n_successful_folds'],
                            'stability': result['consistency_score'],
                            'confidence': result['avg_confidence'],
                            'target_type': 'multi_timeframe_enhanced'
                        },
                        "INFO",
                        "ML Validation"
                    )
                
                return result
            else:
                return {'success': False, 'reason': 'No successful folds'}

        except Exception as e:
            if self.error_handler:
                self.error_handler.handle_ml_error(e, symbol, "walk_forward_validation")
            return {'success': False, 'reason': str(e)}

    def predict_enhanced(self, symbol: str, df: pd.DataFrame) -> Dict:
        if symbol not in self.models:
            return self.fallback_prediction_strategy(symbol, df)
            
        try:
            if len(df) < 50:
                return self.fallback_prediction_strategy(symbol, df)
                
            features = self.prepare_features_point_in_time(df, len(df)-1)
            
            if features.empty:
                return self.fallback_prediction_strategy(symbol, df)
            
            selected_features = self.feature_importance.get(symbol, {}).get('selected_features', [])
            if selected_features:
                missing_features = set(selected_features) - set(features.columns)
                if missing_features:
                    available_features = [f for f in selected_features if f in features.columns]
                    if not available_features:
                        return self.fallback_prediction_strategy(symbol, df)
                    features_selected = features[available_features]
                else:
                    features_selected = features[selected_features]
            else:
                features_selected = features
            
            drift_result = self.detect_feature_drift(symbol, features_selected)
                
            scaled_features = self.scalers[symbol].transform(features_selected)

            rf_pred = self.models[symbol]['rf'].predict(scaled_features)[0]
            gb_pred = self.models[symbol]['gb'].predict(scaled_features)[0]

            rf_proba = self.models[symbol]['rf'].predict_proba(scaled_features)[0]
            gb_proba = self.models[symbol]['gb'].predict_proba(scaled_features)[0]

            rf_confidence = max(rf_proba)
            gb_confidence = max(gb_proba)
            
            rf_confidence_calibrated = self._calibrate_confidence(rf_proba, rf_pred)
            gb_confidence_calibrated = self._calibrate_confidence(gb_proba, gb_pred)

            ensemble_used = False
            if symbol in self.previous_models:
                try:
                    previous_feature_set = self.previous_models[symbol].get('feature_set', [])
                    if not previous_feature_set:
                        previous_feature_set = selected_features
                    
                    available_previous_features = [f for f in previous_feature_set if f in features.columns]
                    
                    if not available_previous_features:
                        raise Exception("No common features with previous model")
                        
                    previous_features_selected = features[available_previous_features]
                    previous_scaled_features = self.previous_scalers[symbol].transform(previous_features_selected)
                    
                    previous_rf_pred = self.previous_models[symbol]['rf'].predict(previous_scaled_features)[0]
                    previous_gb_pred = self.previous_models[symbol]['gb'].predict(previous_scaled_features)[0]
                    
                    previous_rf_proba = self.previous_models[symbol]['rf'].predict_proba(previous_scaled_features)[0]
                    previous_gb_proba = self.previous_models[symbol]['gb'].predict_proba(previous_scaled_features)[0]
                    
                    previous_rf_confidence = max(previous_rf_proba)
                    previous_gb_confidence = max(previous_gb_proba)
                    
                    rf_pred = self._blend_predictions_enhanced(rf_pred, previous_rf_pred, rf_confidence_calibrated, previous_rf_confidence)
                    gb_pred = self._blend_predictions_enhanced(gb_pred, previous_gb_pred, gb_confidence_calibrated, previous_gb_confidence)
                    
                    rf_confidence = (rf_confidence_calibrated * self.ensemble_weight_current + 
                                previous_rf_confidence * self.ensemble_weight_previous)
                    gb_confidence = (gb_confidence_calibrated * self.ensemble_weight_current + 
                                previous_gb_confidence * self.ensemble_weight_previous)
                    
                    ensemble_used = True
                except Exception as e:
                    pass

            if rf_pred == gb_pred:
                ensemble_vote = rf_pred
                confidence = (rf_confidence + gb_confidence) / 2
            else:
                rf_strength = abs(rf_proba[1] - rf_proba[0]) if len(rf_proba) > 1 else rf_confidence
                gb_strength = abs(gb_proba[1] - gb_proba[0]) if len(gb_proba) > 1 else gb_confidence
                
                if rf_strength > gb_strength:
                    ensemble_vote = rf_pred
                    confidence = rf_confidence
                else:
                    ensemble_vote = gb_pred
                    confidence = gb_confidence

            trading_signal = self._convert_to_trading_signal(ensemble_vote)
            
            result = {
                'prediction': trading_signal,
                'raw_prediction': ensemble_vote,
                'confidence': confidence,
                'rf_pred': rf_pred,
                'gb_pred': gb_pred,
                'rf_confidence': rf_confidence,
                'gb_confidence': gb_confidence,
                'timestamp': datetime.now(),
                'model_used': 'ml_ensemble_enhanced',
                'feature_drift': drift_result,
                'quality_metrics': self._get_current_quality_metrics(symbol),
                'ensemble_used': ensemble_used,
                'training_bars_used': self.model_versions.get(symbol, {}).get('training_bars_used', 0),
                'feature_count_used': len(selected_features) if selected_features else len(features.columns),
                'target_type': 'multi_timeframe_enhanced'
            }
            
            if self.database:
                self.database.store_prediction_quality(
                    symbol=symbol,
                    prediction=trading_signal,
                    actual=None,
                    confidence=confidence,
                    model_used='ml_ensemble_enhanced',
                    features_used=selected_features if selected_features else features.columns.tolist(),
                    ensemble_used=ensemble_used
                )
            
            self._update_real_time_monitoring(symbol, result)
            
            return result
            
        except Exception as e:
            return self.fallback_prediction_strategy(symbol, df)

    def _calibrate_confidence(self, probabilities: np.ndarray, prediction: int) -> float:
        try:
            if len(probabilities) <= 1:
                return probabilities[0] if len(probabilities) == 1 else 0.5
            
            sorted_probs = np.sort(probabilities)[::-1]
            if len(sorted_probs) > 1:
                confidence = sorted_probs[0] - sorted_probs[1]
            else:
                confidence = sorted_probs[0]
            
            calibrated = 1.0 / (1.0 + np.exp(-10 * (confidence - 0.5)))
            
            return min(1.0, max(0.0, calibrated))
            
        except:
            return probabilities[prediction] if prediction < len(probabilities) else 0.5

    def _blend_predictions_enhanced(self, current_pred: int, previous_pred: int, 
                                  current_confidence: float, previous_confidence: float) -> int:
        if current_pred == previous_pred:
            return current_pred
        
        current_weight = current_confidence ** 2 * self.ensemble_weight_current
        previous_weight = previous_confidence ** 2 * self.ensemble_weight_previous
        
        if current_weight > previous_weight:
            return current_pred
        else:
            return previous_pred

    def _convert_to_trading_signal(self, raw_prediction: int) -> int:
        if raw_prediction >= 1:
            return 1
        elif raw_prediction <= -1:
            return -1
        else:
            return 0

    def get_model_analytics(self, symbol: str) -> Dict:
        if symbol not in self.model_versions:
            return {'error': 'Model not found'}
        
        model_info = self.model_versions[symbol]
        feature_info = self.feature_importance.get(symbol, {})
        wf_perf = self.walk_forward_performance.get(symbol, {})
        
        analytics = {
            'performance_metrics': {
                'accuracy': model_info.get('accuracy', 0),
                'precision': model_info.get('rf_precision', 0),
                'recall': model_info.get('rf_recall', 0),
                'f1_score': model_info.get('rf_f1', 0),
                'walk_forward_accuracy': wf_perf.get('avg_accuracy', 0),
                'consistency_score': wf_perf.get('consistency_score', 0)
            },
            'training_characteristics': {
                'training_samples': model_info.get('training_samples', 0),
                'feature_count': model_info.get('feature_count', 0),
                'target_type': model_info.get('target_type', 'unknown'),
                'hyperparameters_optimized': model_info.get('hyperparameters_optimized', False),
                'training_duration_seconds': model_info.get('training_duration_seconds', 0)
            },
            'model_health': self._assess_model_health_enhanced(symbol),
            'feature_analysis': {
                'selected_features': feature_info.get('selected_features', []),
                'rf_importance': feature_info.get('rf_importance', []),
                'gb_importance': feature_info.get('gb_importance', []),
                'original_feature_count': feature_info.get('original_feature_count', 0)
            },
            'validation_metrics': {
                'overfit_scores': model_info.get('overfit_scores', {}),
                'walk_forward_folds': wf_perf.get('n_successful_folds', 0),
                'fold_performance_range': f"{wf_perf.get('min_accuracy', 0):.3f}-{wf_perf.get('max_accuracy', 0):.3f}"
            }
        }
        
        return analytics

    def _assess_model_health_enhanced(self, symbol: str) -> Dict:
        model_info = self.model_versions.get(symbol, {})
        wf_perf = self.walk_forward_performance.get(symbol, {})
        
        health_score = 0
        issues = []
        recommendations = []
        
        accuracy = model_info.get('accuracy', 0)
        if accuracy > 0.65:
            health_score += 30
        elif accuracy > 0.55:
            health_score += 20
            issues.append("Moderate accuracy")
            recommendations.append("Consider feature engineering or more training data")
        else:
            health_score += 10
            issues.append("Low accuracy")
            recommendations.append("Retrain with different parameters or more data")
        
        overfit_scores = model_info.get('overfit_scores', {})
        max_overfit = max(overfit_scores.get('rf', 0), overfit_scores.get('gb', 0))
        if max_overfit < 0.08:
            health_score += 25
        elif max_overfit < 0.15:
            health_score += 15
            issues.append("Mild overfitting")
            recommendations.append("Increase regularization or reduce model complexity")
        else:
            health_score += 5
            issues.append("Significant overfitting")
            recommendations.append("Reduce feature count or increase regularization")
        
        consistency = wf_perf.get('consistency_score', 0)
        if consistency > 0.8:
            health_score += 25
        elif consistency > 0.6:
            health_score += 15
            issues.append("Moderate performance variance")
            recommendations.append("Model may be sensitive to market regime changes")
        else:
            health_score += 5
            issues.append("High performance variance")
            recommendations.append("Consider ensemble methods or regime-specific models")
        
        feature_count = model_info.get('feature_count', 0)
        if 15 <= feature_count <= 30:
            health_score += 20
        elif 10 <= feature_count <= 40:
            health_score += 15
            issues.append("Suboptimal feature count")
            recommendations.append("Review feature selection strategy")
        else:
            health_score += 5
            issues.append("Poor feature selection")
            recommendations.append("Re-evaluate feature engineering and selection")
        
        if health_score >= 85:
            rating = 'EXCELLENT'
        elif health_score >= 70:
            rating = 'GOOD'
        elif health_score >= 50:
            rating = 'FAIR'
        else:
            rating = 'POOR'
        
        return {
            'health_score': health_score,
            'health_rating': rating,
            'issues': issues,
            'recommendations': recommendations,
            'components': {
                'accuracy_score': min(30, int(accuracy * 30)),
                'overfitting_score': 25 - min(20, int(max_overfit * 100)),
                'consistency_score': min(25, int(consistency * 25)),
                'feature_score': min(20, feature_count)
            }
        }

    def _calculate_rsi_point_in_time(self, prices: pd.Series, period: int) -> float:
        if len(prices) < period + 1:
            return 50.0
            
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        
        return rsi.iloc[-1] if not pd.isna(rsi.iloc[-1]) else 50.0

    def _calculate_atr_point_in_time(self, high: pd.Series, low: pd.Series, close: pd.Series, period: int) -> float:
        try:
            tr1 = high - low
            tr2 = abs(high - close.shift())
            tr3 = abs(low - close.shift())
            tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
            atr = tr.rolling(period).mean()
            return atr.iloc[-1] if not pd.isna(atr.iloc[-1]) else (high.iloc[-1] - low.iloc[-1])
        except:
            return high.iloc[-1] - low.iloc[-1]

    def _calculate_bollinger_bands_point_in_time(self, series: pd.Series, period: int, std_dev: float) -> Tuple[float, float, float]:
        try:
            middle = series.rolling(period).mean()
            std = series.rolling(period).std()
            upper = middle + (std * std_dev)
            lower = middle - (std * std_dev)
            return (upper.iloc[-1], middle.iloc[-1], lower.iloc[-1])
        except:
            current_price = series.iloc[-1]
            return (current_price * 1.1, current_price, current_price * 0.9)

    def _calculate_macd_point_in_time(self, series: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9) -> Tuple[float, float]:
        try:
            exp1 = series.ewm(span=fast).mean()
            exp2 = series.ewm(span=slow).mean()
            macd = exp1 - exp2
            macd_signal = macd.ewm(span=signal).mean()
            return macd.iloc[-1], macd_signal.iloc[-1]
        except:
            return 0.0, 0.0

    def _calculate_market_regime_feature(self, close: pd.Series, high: pd.Series, low: pd.Series) -> float:
        try:
            if len(close) < 50:
                return 0.0
            
            sma_20 = close.rolling(20).mean()
            sma_50 = close.rolling(50).mean()
            sma_100 = close.rolling(100).mean()
            
            trend_strength = 0.0
            if sma_20.iloc[-1] > sma_50.iloc[-1] > sma_100.iloc[-1]:
                trend_strength = 1.0
            elif sma_20.iloc[-1] < sma_50.iloc[-1] < sma_100.iloc[-1]:
                trend_strength = -1.0
                
            volatility = close.pct_change().rolling(20).std().iloc[-1]
            if volatility > 0.03:
                trend_strength *= 0.7
            elif volatility < 0.01:
                trend_strength *= 1.3
                
            return trend_strength
        except:
            return 0.0

    def _calculate_volatility_regime_feature(self, close: pd.Series) -> float:
        try:
            volatility = close.pct_change().rolling(20).std().iloc[-1]
            if volatility > 0.03:
                return 1.0
            elif volatility < 0.01:
                return -1.0
            else:
                return 0.0
        except:
            return 0.0

    def _calculate_price_efficiency(self, close: pd.Series) -> float:
        try:
            if len(close) < 20:
                return 0.5
                
            returns = close.pct_change().dropna()
            if len(returns) < 10:
                return 0.5
                
            abs_returns = returns.abs()
            net_movement = returns.sum()
            total_movement = abs_returns.sum()
            
            if total_movement == 0:
                return 0.5
                
            return abs(net_movement / total_movement)
        except:
            return 0.5

    def _calculate_hurst_exponent(self, series: pd.Series, max_lag: int = 20) -> float:
        try:
            lags = range(2, min(max_lag, len(series)//2))
            tau = [np.std(np.subtract(series[lag:].values, series[:-lag].values)) for lag in lags]
            poly = np.polyfit(np.log(lags), np.log(tau), 1)
            return poly[0]
        except:
            return 0.5

    def _calculate_market_microstructure_1(self, high: pd.Series, low: pd.Series, close: pd.Series, volume: pd.Series) -> float:
        try:
            if len(close) < 10:
                return 0.0
                
            price_range = (high - low) / close
            volume_weighted_range = (price_range * volume).rolling(10).mean()
            return volume_weighted_range.iloc[-1] if not pd.isna(volume_weighted_range.iloc[-1]) else 0.0
        except:
            return 0.0

    def _calculate_market_microstructure_2(self, high: pd.Series, low: pd.Series, close: pd.Series, volume: pd.Series) -> float:
        try:
            if len(close) < 10:
                return 0.0
                
            close_returns = close.pct_change()
            volume_returns = volume.pct_change()
            correlation = close_returns.rolling(10).corr(volume_returns)
            return correlation.iloc[-1] if not pd.isna(correlation.iloc[-1]) else 0.0
        except:
            return 0.0

    def _select_features(self, X_train: pd.DataFrame, y_train: pd.Series, symbol: str) -> Tuple[pd.DataFrame, List[str]]:
        try:
            available_features = [f for f in self.fixed_feature_set if f in X_train.columns]
            
            if len(available_features) <= self.max_features:
                return X_train[available_features], available_features
            
            if self.feature_selection_method == 'importance':
                rf_temp = RandomForestClassifier(**self.rf_params)
                rf_temp.fit(X_train[available_features], y_train)
                
                importance_df = pd.DataFrame({
                    'feature': available_features,
                    'importance': rf_temp.feature_importances_
                }).sort_values('importance', ascending=False)
                
                selected_features = importance_df.head(self.max_features)['feature'].tolist()
                X_selected = X_train[selected_features]
                
            elif self.feature_selection_method == 'rfe':
                estimator = RandomForestClassifier(**self.rf_params)
                selector = RFE(estimator, n_features_to_select=self.max_features, step=5)
                selector.fit(X_train[available_features], y_train)
                selected_features = [available_features[i] for i in range(len(available_features)) if selector.support_[i]]
                X_selected = X_train[selected_features]
                
            elif self.feature_selection_method == 'lasso':
                lasso = LassoCV(cv=5, random_state=42)
                lasso.fit(X_train[available_features], y_train)
                
                importance_df = pd.DataFrame({
                    'feature': available_features,
                    'coefficient': lasso.coef_
                }).sort_values('coefficient', key=abs, ascending=False)
                
                selected_features = importance_df.head(self.max_features)['feature'].tolist()
                X_selected = X_train[selected_features]
                
            else:
                corr_matrix = X_train[available_features].corr().abs()
                upper_tri = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
                to_drop = [column for column in upper_tri.columns if any(upper_tri[column] > 0.95)]
                selected_features = [col for col in available_features if col not in to_drop][:self.max_features]
                X_selected = X_train[selected_features]
            
            if symbol not in self.feature_importance:
                self.feature_importance[symbol] = {}
            
            self.feature_importance[symbol]['selected_features'] = selected_features
            self.feature_importance[symbol]['original_feature_count'] = len(available_features)
            
            return X_selected, selected_features
            
        except Exception as e:
            variances = X_train[available_features].var().sort_values(ascending=False)
            selected_features = variances.head(self.max_features).index.tolist()
            return X_train[selected_features], selected_features

    def _apply_pca(self, X_train: pd.DataFrame, X_test: pd.DataFrame = None) -> Tuple[np.ndarray, np.ndarray]:
        try:
            pca = PCA(n_components=self.pca_components, random_state=42)
            X_train_pca = pca.fit_transform(X_train)
            
            if X_test is not None:
                X_test_pca = pca.transform(X_test)
                return X_train_pca, X_test_pca
            else:
                return X_train_pca, None
                
        except Exception as e:
            if X_test is not None:
                return X_train.values, X_test.values
            else:
                return X_train.values, None

    def time_series_train_test_split(self, features: pd.DataFrame, target: pd.Series, test_size: float = 0.2):
        if len(features) < 100:
            return None, None, None, None
            
        split_idx = int(len(features) * (1 - test_size))
        
        X_train = features.iloc[:split_idx]
        X_test = features.iloc[split_idx:]
        y_train = target.iloc[:split_idx]
        y_test = target.iloc[split_idx:]
        
        if len(X_train) < 50 or len(X_test) < 10:
            return None, None, None, None
            
        return X_train, X_test, y_train, y_test

    def _record_training_failure(self, symbol: str, reason: str):
        if not hasattr(self, 'model_versions'):
            self.model_versions = {}
            
        self.model_versions[symbol] = {
            'version': f"v{datetime.now().strftime('%Y%m%d_%H%M')}_{reason}",
            'training_date': datetime.now(),
            'accuracy': 0.5,
            'rf_accuracy': 0.5,
            'gb_accuracy': 0.5,
            'rf_precision': 0.5,
            'gb_precision': 0.5,
            'rf_recall': 0.5,
            'gb_recall': 0.5,
            'rf_f1': 0.5,
            'gb_f1': 0.5,
            'training_samples': 0,
            'test_samples': 0,
            'status': reason
        }

    def _store_training_results(self, symbol: str, model_version: str, training_duration: float,
                              rf_accuracy: float, gb_accuracy: float, rf_precision: float, gb_precision: float,
                              rf_recall: float, gb_recall: float, rf_f1: float, gb_f1: float,
                              train_samples: int, test_samples: int, bars_used: int, features: List[str],
                              rf_params: dict, gb_params: dict):
        try:
            current_accuracy = (rf_accuracy + gb_accuracy) / 2
            current_precision = (rf_precision + gb_precision) / 2
            current_recall = (rf_recall + gb_recall) / 2
            current_f1 = (rf_f1 + gb_f1) / 2

            self.database.store_ml_model_performance(symbol, {
                'accuracy': current_accuracy,
                'precision': current_precision,
                'recall': current_recall,
                'f1_score': current_f1,
                'rf_accuracy': rf_accuracy,
                'gb_accuracy': gb_accuracy,
                'rf_precision': rf_precision,
                'gb_precision': gb_precision,
                'rf_recall': rf_recall,
                'gb_recall': gb_recall,
                'rf_f1': rf_f1,
                'gb_f1': gb_f1,
                'training_samples': train_samples,
                'test_samples': test_samples,
                'model_version': model_version,
                'training_bars_used': bars_used,
                'feature_count': len(features),
                'target_type': 'multi_timeframe_enhanced',
                'hyperparameters_optimized': self.enable_hyperparameter_optimization
            })
            
            self.database.store_model_training_history(symbol, {
                'model_version': model_version,
                'training_date': datetime.now(),
                'training_duration_seconds': training_duration,
                'training_samples': train_samples,
                'test_samples': test_samples,
                'final_accuracy': current_accuracy,
                'final_precision': current_precision,
                'final_recall': current_recall,
                'final_f1': current_f1,
                'feature_count': len(features),
                'parameters_used': {'rf': rf_params, 'gb': gb_params},
                'training_bars_used': bars_used
            })
            
            self.database.store_system_event(
                "HYPERPARAMETER_OPTIMIZATION",
                {
                    'symbol': symbol,
                    'rf_params': rf_params,
                    'gb_params': gb_params,
                    'feature_selection_method': self.feature_selection_method
                },
                "INFO",
                "ML Training"
            )
            
        except Exception as db_error:
            pass

    def _calculate_balanced_accuracy(self, y_true, y_pred):
        try:
            classes = np.unique(y_true)
            class_accuracies = []
            
            for cls in classes:
                if np.sum(y_true == cls) > 0:
                    cls_accuracy = np.mean(y_pred[y_true == cls] == cls)
                    class_accuracies.append(cls_accuracy)
            
            return np.mean(class_accuracies) if class_accuracies else 0.0
        except:
            return accuracy_score(y_true, y_pred)

    def _initialize_feature_drift_detector(self, symbol: str, X_train: np.ndarray):
        try:
            detector = EllipticEnvelope(contamination=0.1, random_state=42)
            detector.fit(X_train)
            self.feature_drift_detector[symbol] = detector
            
            if self.database:
                self.database.store_model_drift_detection(symbol, {
                    'accuracy_drift': 0,
                    'feature_drift': 0,
                    'prediction_drift': 0,
                    'drift_detected': False,
                    'drift_reason': 'Initial model training',
                    'retraining_recommended': False
                })
                
        except Exception as e:
            pass

    def _initialize_prediction_quality_tracking(self, symbol: str):
        self.prediction_quality_metrics[symbol] = {
            'predictions': [],
            'actuals': [],
            'timestamps': [],
            'accuracies': [],
            'precisions': [],
            'recalls': [],
            'f1_scores': []
        }

    def detect_feature_drift(self, symbol: str, current_features: pd.DataFrame) -> Dict:
        try:
            if symbol not in self.feature_drift_detector:
                return {'drift_detected': False, 'reason': 'No drift detector initialized'}
            
            if current_features.empty:
                return {'drift_detected': False, 'reason': 'No current features'}
            
            if symbol not in self.scalers:
                return {'drift_detected': False, 'reason': 'No scaler available'}
                
            scaler = self.scalers[symbol]
            
            if len(current_features) == 1:
                current_scaled = scaler.transform(current_features)
            else:
                expected_features = getattr(scaler, 'n_features_in_', current_features.shape[1])
                if current_features.shape[1] != expected_features:
                    return {'drift_detected': False, 'reason': f'Feature dimension mismatch: {current_features.shape[1]} vs {expected_features}'}
                current_scaled = scaler.transform(current_features)
            
            detector = self.feature_drift_detector[symbol]
            drift_scores = detector.decision_function(current_scaled)
            
            threshold = np.percentile(drift_scores, 10)
            drift_detected = np.any(drift_scores < threshold)
            
            drift_ratio = np.sum(drift_scores < threshold) / len(drift_scores) if len(drift_scores) > 0 else 0
            
            result = {
                'drift_detected': bool(drift_detected),
                'drift_ratio': float(drift_ratio),
                'drift_scores': [float(score) for score in drift_scores.tolist()],
                'threshold_violations': int(np.sum(drift_scores < 0))
            }
            
            if self.database:
                try:
                    self.database.store_model_drift_detection(symbol, {
                        'accuracy_drift': 0.0,
                        'feature_drift': float(drift_ratio),
                        'prediction_drift': 0.0,
                        'drift_detected': bool(drift_detected),
                        'drift_reason': 'Feature distribution change detected' if drift_detected else 'No significant drift',
                        'retraining_recommended': bool(drift_detected and drift_ratio > 0.3)
                    })
                except Exception as db_error:
                    pass
            
            return result
            
        except Exception as e:
            return {
                'drift_detected': False, 
                'reason': str(e),
                'drift_ratio': 0.0,
                'drift_scores': [],
                'threshold_violations': 0
            }

    def monitor_prediction_quality(self, symbol: str, prediction: int, actual: int, timestamp: datetime):
        try:
            if symbol not in self.prediction_quality_metrics:
                self._initialize_prediction_quality_tracking(symbol)
            
            metrics = self.prediction_quality_metrics[symbol]
            metrics['predictions'].append(prediction)
            metrics['actuals'].append(actual)
            metrics['timestamps'].append(timestamp)
            
            if len(metrics['predictions']) > self.quality_metrics_window:
                for key in ['predictions', 'actuals', 'timestamps']:
                    metrics[key].pop(0)
            
            if len(metrics['predictions']) >= 10:
                accuracy = accuracy_score(metrics['actuals'], metrics['predictions'])
                precision = precision_score(metrics['actuals'], metrics['predictions'], 
                                        average='weighted', zero_division=0)
                recall = recall_score(metrics['actuals'], metrics['predictions'],
                                    average='weighted', zero_division=0)
                f1 = f1_score(metrics['actuals'], metrics['predictions'],
                            average='weighted', zero_division=0)
                
                for metric_list, value in [('accuracies', accuracy), 
                                        ('precisions', precision),
                                        ('recalls', recall), 
                                        ('f1_scores', f1)]:
                    metrics[metric_list].append(value)
                    if len(metrics[metric_list]) > 20:
                        metrics[metric_list].pop(0)
                        
        except Exception as e:
            pass

    def _get_current_quality_metrics(self, symbol: str) -> Dict:
        try:
            if symbol not in self.prediction_quality_metrics:
                return {}
                
            metrics = self.prediction_quality_metrics[symbol]
            if not metrics['accuracies']:
                return {}
                
            return {
                'recent_accuracy': metrics['accuracies'][-1] if metrics['accuracies'] else 0,
                'recent_precision': metrics['precisions'][-1] if metrics['precisions'] else 0,
                'recent_recall': metrics['recalls'][-1] if metrics['recalls'] else 0,
                'recent_f1': metrics['f1_scores'][-1] if metrics['f1_scores'] else 0,
                'accuracy_trend': np.mean(metrics['accuracies'][-5:]) if len(metrics['accuracies']) >= 5 else 0,
                'monitoring_window': len(metrics['predictions'])
            }
        except:
            return {}

    def _update_real_time_monitoring(self, symbol: str, prediction_result: Dict):
        try:
            if symbol not in self.real_time_monitor:
                self.real_time_monitor[symbol] = {
                    'prediction_count': 0,
                    'confidence_sum': 0.0,
                    'drift_alerts': 0,
                    'quality_alerts': 0,
                    'last_update': datetime.now().isoformat(),
                    'last_drift_ratio': 0.0
                }

            monitor = self.real_time_monitor[symbol]
            monitor['prediction_count'] += 1
            monitor['confidence_sum'] += float(prediction_result['confidence'])
            
            monitor['last_update'] = datetime.now().isoformat()

            drift_info = prediction_result.get('feature_drift', {})
            drift_ratio = drift_info.get('drift_ratio', 0.0)
            
            if isinstance(drift_ratio, bytes):
                try:
                    drift_ratio = float(drift_ratio.decode('utf-8'))
                except:
                    drift_ratio = 0.0
            else:
                drift_ratio = float(drift_ratio)

            if drift_info.get('drift_detected', False):
                monitor['drift_alerts'] += 1

            monitor['last_drift_ratio'] = drift_ratio

        except Exception as e:
            if symbol not in self.real_time_monitor:
                self.real_time_monitor[symbol] = {
                    'prediction_count': 0,
                    'confidence_sum': 0.0,
                    'drift_alerts': 0,
                    'quality_alerts': 0,
                    'last_update': datetime.now().isoformat(),
                    'last_drift_ratio': 0.0
                }

    def fallback_prediction_strategy(self, symbol: str, df: pd.DataFrame) -> Dict:
        try:
            close_prices = df['close'].astype(float)
            
            if len(close_prices) < 50:
                raise Exception("Insufficient data for fallback TA")

            momentum_5 = close_prices.pct_change(5).iloc[-1]
            sma_5 = close_prices.rolling(5).mean().iloc[-1]
            sma_20 = close_prices.rolling(20).mean().iloc[-1]
            sma_50 = close_prices.rolling(50).mean().iloc[-1]
            rsi = self._calculate_rsi_point_in_time(close_prices, 14)
            
            if (sma_5 > sma_20 > sma_50 and momentum_5 > 0 and rsi < 70):
                prediction = 1
                confidence = 0.65
            elif (sma_5 < sma_20 < sma_50 and momentum_5 < 0 and rsi > 30):
                prediction = -1
                confidence = 0.65
            else:
                prediction = 0
                confidence = 0.5
            
            return {
                'prediction': prediction,
                'confidence': confidence,
                'fallback_method': 'enhanced_technical_analysis',
                'momentum_5': momentum_5,
                'sma_5': sma_5,
                'sma_20': sma_20,
                'sma_50': sma_50,
                'rsi': rsi
            }
            
        except Exception as e:
            return {
                'prediction': 0,
                'confidence': 0.3,
                'fallback_method': 'error_fallback'
            }

    def update_prediction_actual(self, symbol: str, prediction_timestamp: datetime, actual: int):
        try:
            if self.database:
                pass
                
            if symbol in self.prediction_quality_metrics:
                metrics = self.prediction_quality_metrics[symbol]
                if len(metrics['actuals']) > 0:
                    metrics['actuals'][-1] = actual
                        
        except Exception as e:
            pass

    def get_model_info(self) -> Dict:
        info = {
            'total_models': len(self.models),
            'model_versions': self.model_versions,
            'walk_forward_performance': self.walk_forward_performance,
            'performance_history': self.performance_history,
            'feature_importance_available': len(self.feature_importance) > 0,
            'prediction_quality_metrics': {
                symbol: self._get_current_quality_metrics(symbol)
                for symbol in self.prediction_quality_metrics
            },
            'real_time_monitoring': self.real_time_monitor,
            'previous_models_available': len(self.previous_models),
            'ensemble_config': {
                'current_weight': self.ensemble_weight_current,
                'previous_weight': self.ensemble_weight_previous
            },
            'model_health': self._get_model_health_summary(),
            'feature_selection_config': {
                'max_features': self.max_features,
                'method': self.feature_selection_method,
                'use_pca': self.use_pca
            },
            'training_config': {
                'target_type': 'multi_timeframe_enhanced',
                'hyperparameter_optimization': self.enable_hyperparameter_optimization,
                'multi_timeframe_configs': self.target_configs
            }
        }
        return info
    
    def _get_model_health_summary(self) -> Dict:
        health_summary = {}
        for symbol, version_info in self.model_versions.items():
            accuracy = version_info.get('accuracy', 0.5)
            training_date = version_info.get('training_date')
            
            if training_date:
                if isinstance(training_date, str):
                    try:
                        training_date = datetime.fromisoformat(training_date.replace('Z', '+00:00'))
                    except ValueError:
                        training_date = datetime.now()
                
                days_since_training = (datetime.now() - training_date).days
                needs_retraining = days_since_training > 30 or accuracy < 0.55
            else:
                needs_retraining = accuracy < 0.55
            
            health_summary[symbol] = {
                'accuracy': accuracy,
                'rf_accuracy': version_info.get('rf_accuracy', 0),
                'gb_accuracy': version_info.get('gb_accuracy', 0),
                'training_date': training_date.strftime('%Y-%m-%d') if training_date else 'Unknown',
                'days_since_training': days_since_training if training_date else 999,
                'needs_retraining': needs_retraining,
                'status': 'excellent' if accuracy > 0.7 else 'good' if accuracy > 0.6 else 'fair' if accuracy > 0.55 else 'poor',
                'feature_count': version_info.get('feature_count', 0),
                'overfit_score': version_info.get('overfit_scores', {}).get('rf', 0),
                'target_type': version_info.get('target_type', 'unknown')
            }
        
        return health_summary

    def force_reset_models(self):
        self.models = {}
        self.previous_models = {}
        self.scalers = {}
        self.previous_scalers = {}
        self.model_versions = {}
        self.feature_importance = {}
        self.walk_forward_performance = {}
        self.performance_history = {}
        self.prediction_quality_metrics = {}
        self.feature_drift_detector = {}
        self.real_time_monitor = {}
        
        if hasattr(self, 'training_in_progress'):
            self.training_in_progress = False
        if hasattr(self, 'current_training_symbol'):
            self.current_training_symbol = None
        
        import shutil
        try:
            shutil.rmtree("ml_models", ignore_errors=True)
        except:
            pass
        
        return True

    def _serialize_metadata(self, data):
        if isinstance(data, dict):
            return {k: self._serialize_metadata(v) for k, v in data.items()}
        elif isinstance(data, list):
            return [self._serialize_metadata(item) for item in data]
        elif isinstance(data, (np.integer, np.int64, np.int32)):
            return int(data)
        elif isinstance(data, (np.floating, np.float64)):
            return float(data)
        elif isinstance(data, np.bool_):
            return bool(data)
        elif isinstance(data, np.ndarray):
            return data.tolist()
        elif hasattr(data, 'isoformat'):
            return data.isoformat()
        else:
            return data

    def save_models(self, base_path: str = "ml_models") -> bool:
        try:
            if not os.path.exists(base_path):
                os.makedirs(base_path)
                
            saved_count = 0
            
            try:
                metadata_path = os.path.join(base_path, "_metadata.joblib")
                metadata_to_save = {
                    'model_versions': self._serialize_metadata(self.model_versions),
                    'feature_importance': self._serialize_metadata(self.feature_importance),
                    'performance_history': self._serialize_metadata(self.performance_history),
                    'walk_forward_performance': self._serialize_metadata(self.walk_forward_performance),
                    'ensemble_config': {
                        'current_weight': self.ensemble_weight_current,
                        'previous_weight': self.ensemble_weight_previous
                    },
                    'feature_selection_config': {
                        'max_features': self.max_features,
                        'method': self.feature_selection_method,
                        'use_pca': self.use_pca
                    },
                    'training_config': {
                        'target_configs': self.target_configs,
                        'enable_hpo': self.enable_hyperparameter_optimization
                    },
                    'fixed_feature_set': self.fixed_feature_set
                }
                joblib.dump(metadata_to_save, metadata_path, compress=3)
            except Exception as meta_e:
                pass

            for symbol, model_data in self.models.items():
                model_path = os.path.join(base_path, f"{symbol}_model.joblib")
                scaler_path = os.path.join(base_path, f"{symbol}_scaler.joblib")
                drift_detector_path = os.path.join(base_path, f"{symbol}_drift_detector.joblib")
                
                previous_model_path = os.path.join(base_path, f"{symbol}_previous_model.joblib")
                previous_scaler_path = os.path.join(base_path, f"{symbol}_previous_scaler.joblib")
                
                model_data_to_save = {
                    'rf': model_data['rf'],
                    'gb': model_data['gb'],
                    'model_version': self.model_versions.get(symbol, {}).get('version', 'v1'),
                    'trained_date': datetime.now().isoformat(),
                    'feature_set': self.feature_importance.get(symbol, {}).get('selected_features', [])
                }
                
                joblib.dump(model_data_to_save, model_path, compress=3)
                joblib.dump(self.scalers[symbol], scaler_path, compress=3)
                
                if symbol in self.feature_drift_detector:
                    joblib.dump(self.feature_drift_detector[symbol], drift_detector_path, compress=3)
                
                if symbol in self.previous_models:
                    previous_model_data_to_save = {
                        'rf': self.previous_models[symbol]['rf'],
                        'gb': self.previous_models[symbol]['gb'],
                        'model_version': 'previous',
                        'trained_date': 'previous',
                        'feature_set': self.previous_models[symbol].get('feature_set', [])
                    }
                    joblib.dump(previous_model_data_to_save, previous_model_path, compress=3)
                    joblib.dump(self.previous_scalers[symbol], previous_scaler_path, compress=3)
                
                if os.path.exists(model_path) and os.path.exists(scaler_path):
                    saved_count += 1
            
            return saved_count > 0
            
        except Exception as e:
            return False

    def load_models(self, base_path: str = "ml_models") -> bool:
        try:
            if not os.path.exists(base_path):
                return False
                
            loaded_count = 0

            metadata_path = os.path.join(base_path, "_metadata.joblib")
            if os.path.exists(metadata_path):
                try:
                    metadata = joblib.load(metadata_path)
                    self.model_versions = metadata.get('model_versions', {})
                    self.feature_importance = metadata.get('feature_importance', {})
                    self.performance_history = metadata.get('performance_history', {})
                    self.walk_forward_performance = metadata.get('walk_forward_performance', {})
                    
                    ensemble_config = metadata.get('ensemble_config', {})
                    self.ensemble_weight_current = ensemble_config.get('current_weight', 0.8)
                    self.ensemble_weight_previous = ensemble_config.get('previous_weight', 0.2)
                    
                    feature_config = metadata.get('feature_selection_config', {})
                    self.max_features = feature_config.get('max_features', 25)
                    self.feature_selection_method = feature_config.get('method', 'importance')
                    self.use_pca = feature_config.get('use_pca', False)
                    
                    training_config = metadata.get('training_config', {})
                    self.target_configs = training_config.get('target_configs', self.target_configs)
                    self.enable_hyperparameter_optimization = training_config.get('enable_hpo', True)
                    
                    self.fixed_feature_set = metadata.get('fixed_feature_set', self.fixed_feature_set)
                    
                    if not hasattr(self, 'model_versions'):
                         self.model_versions = {}
                    if not hasattr(self, 'feature_importance'):
                         self.feature_importance = {}
                    if not hasattr(self, 'performance_history'):
                         self.performance_history = {}
                    if not hasattr(self, 'previous_models'):
                         self.previous_models = {}
                    if not hasattr(self, 'previous_scalers'):
                         self.previous_scalers = {}
                         
                except Exception as meta_e:
                    self.model_versions = {}
                    self.feature_importance = {}
                    self.performance_history = {}
                    self.previous_models = {}
                    self.previous_scalers = {}
            else:
                self.model_versions = {}
                self.feature_importance = {}
                self.performance_history = {}
                self.previous_models = {}
                self.previous_scalers = {}

            for filename in os.listdir(base_path):
                if filename.endswith("_model.joblib") and not filename.endswith("_previous_model.joblib"):
                    symbol = filename.replace("_model.joblib", "")
                    model_path = os.path.join(base_path, filename)
                    scaler_path = os.path.join(base_path, f"{symbol}_scaler.joblib")
                    drift_detector_path = os.path.join(base_path, f"{symbol}_drift_detector.joblib")
                    
                    previous_model_path = os.path.join(base_path, f"{symbol}_previous_model.joblib")
                    previous_scaler_path = os.path.join(base_path, f"{symbol}_previous_scaler.joblib")
                    
                    if os.path.exists(scaler_path):
                        try:
                            model_data = joblib.load(model_path)
                            scaler = joblib.load(scaler_path)
                            
                            self.models[symbol] = {'rf': model_data['rf'], 'gb': model_data['gb']}
                            self.scalers[symbol] = scaler
                            
                            if 'feature_set' in model_data:
                                if symbol not in self.feature_importance:
                                    self.feature_importance[symbol] = {}
                                self.feature_importance[symbol]['selected_features'] = model_data['feature_set']
                            
                            if os.path.exists(drift_detector_path):
                                self.feature_drift_detector[symbol] = joblib.load(drift_detector_path)
                            
                            if os.path.exists(previous_model_path) and os.path.exists(previous_scaler_path):
                                previous_model_data = joblib.load(previous_model_path)
                                previous_scaler = joblib.load(previous_scaler_path)
                                
                                self.previous_models[symbol] = {
                                    'rf': previous_model_data['rf'], 
                                    'gb': previous_model_data['gb'],
                                    'feature_set': previous_model_data.get('feature_set', [])
                                }
                                self.previous_scalers[symbol] = previous_scaler
                            
                            self._initialize_prediction_quality_tracking(symbol)

                            if symbol not in self.model_versions:
                                self.model_versions[symbol] = {
                                    'version': model_data.get('model_version', 'v_loaded'),
                                    'training_date': datetime.fromisoformat(model_data.get('trained_date')) if 'trained_date' in model_data else datetime.now(),
                                    'accuracy': 0.5,
                                    'rf_accuracy': 0.5, 'gb_accuracy': 0.5,
                                    'rf_precision': 0.5, 'gb_precision': 0.5,
                                    'rf_recall': 0.5, 'gb_recall': 0.5,
                                    'rf_f1': 0.5, 'gb_f1': 0.5,
                                    'status': 'loaded_no_metadata'
                                }

                            loaded_count += 1
                        except Exception as e:
                            continue
            
            return loaded_count > 0
            
        except Exception as e:
            return False

    def force_save_models(self):
        success = self.save_models()
        return success

    def predict(self, symbol: str, df: pd.DataFrame) -> Dict:
        return self.predict_enhanced(symbol, df)

    def prepare_training_data(self, df: pd.DataFrame, min_samples: int = None) -> tuple:
        return self.prepare_training_data_enhanced(df, min_samples)

    def walk_forward_validation(self, symbol: str, df: pd.DataFrame, n_splits: int = None) -> Dict:
        return self.walk_forward_validation_enhanced(symbol, df, n_splits)