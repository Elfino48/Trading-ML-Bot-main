import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
from datetime import datetime
import json

class MLVisualizer:
    def __init__(self, ml_predictor, database):
        self.ml_predictor = ml_predictor
        self.database = database
        
    def create_model_evolution_dashboard(self, symbol: str) -> dict:
        """Create comprehensive model evolution dashboard"""
        
        # Get model history from database
        model_history = self.database.get_model_training_history(symbol)
        performance_history = self.database.get_ml_model_performance(symbol)
        
        if not model_history:
            return self._create_empty_dashboard(symbol)
        
        # Convert to DataFrame for easier manipulation
        df_history = pd.DataFrame(model_history)
        df_performance = pd.DataFrame(performance_history)
        
        # Create subplots
        fig = make_subplots(
            rows=3, cols=2,
            subplot_titles=(
                'Model Accuracy Over Time', 
                'Training Samples Evolution',
                'Feature Importance Changes',
                'Prediction Confidence Distribution',
                'Model Performance Metrics',
                'Training Duration Trends'
            ),
            specs=[
                [{"secondary_y": False}, {"secondary_y": False}],
                [{"secondary_y": False}, {"secondary_y": False}],
                [{"secondary_y": False}, {"secondary_y": False}]
            ]
        )
        
        # 1. Accuracy over time
        if not df_history.empty:
            fig.add_trace(
                go.Scatter(
                    x=df_history['training_date'], 
                    y=df_history['final_accuracy'],
                    mode='lines+markers',
                    name='Accuracy',
                    line=dict(color='blue')
                ),
                row=1, col=1
            )
        
        # 2. Training samples evolution
        if not df_history.empty:
            fig.add_trace(
                go.Scatter(
                    x=df_history['training_date'],
                    y=df_history['training_samples'],
                    mode='lines+markers',
                    name='Training Samples',
                    line=dict(color='green')
                ),
                row=1, col=2
            )
        
        # 3. Feature importance (simplified - you'd need to store this)
        feature_data = self._get_feature_importance_data(symbol)
        if feature_data:
            fig.add_trace(
                go.Heatmap(
                    z=feature_data['importance_matrix'],
                    x=feature_data['dates'],
                    y=feature_data['features'],
                    colorscale='Viridis',
                    name='Feature Importance'
                ),
                row=2, col=1
            )
        
        # 4. Performance metrics comparison
        if not df_performance.empty:
            metrics = ['accuracy', 'precision', 'recall', 'f1_score']
            for metric in metrics:
                if metric in df_performance.columns:
                    fig.add_trace(
                        go.Scatter(
                            x=df_performance['timestamp'],
                            y=df_performance[metric],
                            mode='lines',
                            name=metric.title()
                        ),
                        row=2, col=2
                    )
        
        # 5. Training duration
        if not df_history.empty and 'training_duration_seconds' in df_history.columns:
            fig.add_trace(
                go.Scatter(
                    x=df_history['training_date'],
                    y=df_history['training_duration_seconds'],
                    mode='lines+markers',
                    name='Training Duration (s)',
                    line=dict(color='red')
                ),
                row=3, col=1
            )
        
        fig.update_layout(
            height=1200,
            title_text=f"ML Model Evolution - {symbol}",
            showlegend=True
        )
        
        return fig.to_dict()
    
    def create_prediction_analysis_chart(self, symbol: str) -> dict:
        """Create prediction analysis visualization"""
        
        predictions = self.database.get_prediction_quality(symbol, limit=100)
        
        if not predictions:
            return self._create_empty_chart("No prediction data available")
        
        df = pd.DataFrame(predictions)
        
        fig = make_subplots(
            rows=2, cols=2,
            subplot_titles=(
                'Prediction Confidence Over Time',
                'Prediction Accuracy Distribution',
                'Model Type Usage',
                'Feature Drift Detection'
            )
        )
        
        # Confidence over time
        fig.add_trace(
            go.Scatter(
                x=df['timestamp'],
                y=df['confidence'],
                mode='markers',
                name='Confidence',
                marker=dict(
                    size=8,
                    color=df['confidence'],
                    colorscale='RdYlGn',
                    showscale=True
                )
            ),
            row=1, col=1
        )
        
        # Accuracy distribution
        if 'actual' in df.columns and 'prediction' in df.columns:
            accuracy = (df['prediction'] == df['actual']).astype(int)
            fig.add_trace(
                go.Histogram(
                    x=accuracy,
                    name='Accuracy Distribution',
                    nbinsx=3
                ),
                row=1, col=2
            )
        
        # Model type usage
        model_counts = df['model_used'].value_counts()
        fig.add_trace(
            go.Pie(
                labels=model_counts.index,
                values=model_counts.values,
                name='Model Usage'
            ),
            row=2, col=1
        )
        
        fig.update_layout(height=800, title_text=f"Prediction Analysis - {symbol}")
        return fig.to_dict()
    
    def create_feature_importance_chart(self, symbol: str) -> dict:
        """Create feature importance visualization"""
        
        feature_importance = self.database.get_feature_importance(symbol)
        
        if not feature_importance:
            return self._create_empty_chart("No feature importance data available")
        
        # Get latest feature importance
        latest_rf = feature_importance.get('rf', {})
        latest_gb = feature_importance.get('gb', {})
        
        features = list(latest_rf.keys())
        rf_importance = list(latest_rf.values())
        gb_importance = list(latest_gb.values())
        
        fig = go.Figure()
        
        fig.add_trace(go.Bar(
            y=features,
            x=rf_importance,
            name='Random Forest',
            orientation='h',
            marker=dict(color='lightblue')
        ))
        
        fig.add_trace(go.Bar(
            y=features,
            x=gb_importance,
            name='Gradient Boosting',
            orientation='h',
            marker=dict(color='lightcoral')
        ))
        
        fig.update_layout(
            title=f"Feature Importance - {symbol}",
            xaxis_title="Importance Score",
            yaxis_title="Features",
            barmode='group',
            height=600
        )
        
        return fig.to_dict()
    
    def _get_feature_importance_data(self, symbol: str) -> dict:
        """Extract feature importance data for heatmap"""
        # This would need to be implemented based on your stored data
        return None
    
    def _create_empty_dashboard(self, symbol: str) -> dict:
        fig = go.Figure()
        fig.add_annotation(
            text=f"No ML model data available for {symbol}",
            xref="paper", yref="paper",
            x=0.5, y=0.5, xanchor='center', yanchor='middle',
            showarrow=False
        )
        fig.update_layout(title_text=f"ML Model Evolution - {symbol}")
        return fig.to_dict()
    
    def _create_empty_chart(self, message: str) -> dict:
        fig = go.Figure()
        fig.add_annotation(
            text=message,
            xref="paper", yref="paper",
            x=0.5, y=0.5, xanchor='center', yanchor='middle',
            showarrow=False
        )
        return fig.to_dict()