import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
import logging
from scipy.optimize import minimize
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

class AdvancedStrategyOptimizer:
    """
    Advanced dynamic strategy optimization with machine learning integration
    and real-time performance adaptation
    """
    
    def __init__(self, trading_database=None, ml_predictor=None):
        self.database = trading_database
        self.ml_predictor = ml_predictor
        self.optimization_history = []
        self.current_weights = {}
        self.market_regime = "neutral"
        self.volatility_regime = "normal"
        self.performance_metrics = {}
        self.strategy_correlations = {}
        self.regime_transition_matrix = {}
        
        self.logger = logging.getLogger('AdvancedStrategyOptimizer')
        
        # Enhanced regime-specific weights with more granular categories
        self.regime_weights = {
            "strong_bull_trend": {
                'trend_following': 0.50,
                'mean_reversion': 0.15,
                'breakout': 0.25,
                'ml_prediction': 0.10
            },
            "bull_trend": {
                'trend_following': 0.45,
                'mean_reversion': 0.20,
                'breakout': 0.25,
                'ml_prediction': 0.10
            },
            "weak_bull_trend": {
                'trend_following': 0.35,
                'mean_reversion': 0.30,
                'breakout': 0.25,
                'ml_prediction': 0.10
            },
            "strong_bear_trend": {
                'trend_following': 0.40,
                'mean_reversion': 0.30,
                'breakout': 0.20,
                'ml_prediction': 0.10
            },
            "bear_trend": {
                'trend_following': 0.35,
                'mean_reversion': 0.35,
                'breakout': 0.20,
                'ml_prediction': 0.10
            },
            "weak_bear_trend": {
                'trend_following': 0.25,
                'mean_reversion': 0.45,
                'breakout': 0.20,
                'ml_prediction': 0.10
            },
            "high_volatility_ranging": {
                'trend_following': 0.20,
                'mean_reversion': 0.45,
                'breakout': 0.25,
                'ml_prediction': 0.10
            },
            "low_volatility_ranging": {
                'trend_following': 0.15,
                'mean_reversion': 0.50,
                'breakout': 0.25,
                'ml_prediction': 0.10
            },
            "volatility_breakout": {
                'trend_following': 0.25,
                'mean_reversion': 0.30,
                'breakout': 0.35,
                'ml_prediction': 0.10
            },
            "trend_transition": {
                'trend_following': 0.30,
                'mean_reversion': 0.40,
                'breakout': 0.20,
                'ml_prediction': 0.10
            }
        }
        
        # Strategy performance decay factors (how quickly performance relevance fades)
        self.performance_decay_factors = {
            'trend_following': 0.95,  # Slower decay for trend following
            'mean_reversion': 0.90,   # Faster decay for mean reversion
            'breakout': 0.85,         # Fastest decay for breakout
            'ml_prediction': 0.92     # Moderate decay for ML
        }
        
        # Minimum sample sizes for reliable optimization
        self.min_trades_for_optimization = {
            'trend_following': 10,
            'mean_reversion': 15,
            'breakout': 12,
            'ml_prediction': 8
        }
        
        # Optimization constraints
        self.weight_constraints = {
            'min_weight': 0.05,
            'max_weight': 0.60,
            'max_change_per_optimization': 0.15
        }
        
        print("🎯 Advanced Strategy Optimizer initialized with ML integration")
    
    def optimize_weights(self, market_regime: str, volatility: float, 
                        recent_performance: Dict, aggressiveness: str,
                        correlation_matrix: pd.DataFrame = None,
                        market_indicators: Dict = None) -> Dict[str, float]:
        """
        Advanced weight optimization with multiple factors and constraints
        """
        try:
            # Get base weights for current regime with volatility adjustment
            base_weights = self._get_enhanced_base_weights(market_regime, volatility, market_indicators)
            
            # Apply performance-based adjustments with decay
            performance_weights = self._enhanced_performance_adjustment(
                base_weights, recent_performance, market_regime
            )
            
            # Apply correlation-based diversification if correlation matrix provided
            if correlation_matrix is not None:
                performance_weights = self._apply_correlation_adjustment(
                    performance_weights, correlation_matrix
                )
            
            # Apply aggressiveness adjustments
            aggressiveness_weights = self._enhanced_aggressiveness_adjustment(
                performance_weights, aggressiveness, market_regime, volatility
            )
            
            # Apply constraints and normalize
            final_weights = self._apply_optimization_constraints(aggressiveness_weights)
            
            # Store optimization record with detailed metadata
            optimization_record = {
                'timestamp': datetime.now(),
                'market_regime': market_regime,
                'volatility': volatility,
                'aggressiveness': aggressiveness,
                'base_weights': base_weights.copy(),
                'performance_weights': performance_weights.copy(),
                'final_weights': final_weights.copy(),
                'performance_metrics': recent_performance.copy(),
                'optimization_score': self._calculate_optimization_score(final_weights, recent_performance),
                'constraints_violated': self._check_constraints_violations(aggressiveness_weights)
            }
            
            self.optimization_history.append(optimization_record)
            self.current_weights = final_weights
            
            # Limit history size
            if len(self.optimization_history) > 1000:
                self.optimization_history = self.optimization_history[-1000:]
            
            self.logger.info(f"Advanced strategy weights optimized: {final_weights}")
            
            # Store in database if available
            if self.database:
                self._store_optimization_record(optimization_record)
            
            return final_weights
            
        except Exception as e:
            self.logger.error(f"Error in optimize_weights: {e}")
            # Fallback to simple regime-based weights
            return self._get_fallback_weights(market_regime, aggressiveness)
    
    def _get_enhanced_base_weights(self, market_regime: str, volatility: float, 
                                 market_indicators: Dict = None) -> Dict[str, float]:
        """
        Get sophisticated base weights considering multiple market factors
        """
        # Determine detailed regime classification
        detailed_regime = self._classify_detailed_regime(market_regime, volatility, market_indicators)
        
        if detailed_regime in self.regime_weights:
            base_weights = self.regime_weights[detailed_regime].copy()
        else:
            base_weights = self.regime_weights["bull_trend"].copy()
        
        # Apply volatility-based fine-tuning
        volatility_factor = self._calculate_volatility_factor(volatility)
        for strategy in base_weights:
            base_weights[strategy] *= volatility_factor[strategy]
        
        # Apply trend strength adjustment if available
        if market_indicators and 'trend_strength' in market_indicators:
            trend_strength = market_indicators['trend_strength']
            trend_factor = self._calculate_trend_factor(trend_strength)
            for strategy in base_weights:
                base_weights[strategy] *= trend_factor[strategy]
        
        # Normalize
        total = sum(base_weights.values())
        if total > 0:
            base_weights = {k: v/total for k, v in base_weights.items()}
        
        return base_weights
    
    def _classify_detailed_regime(self, market_regime: str, volatility: float, 
                                indicators: Dict = None) -> str:
        """
        Classify market regime with more granularity
        """
        base_regime = market_regime.lower()
        
        # Volatility classification
        if volatility > 0.04:
            vol_class = "high_volatility"
        elif volatility < 0.008:
            vol_class = "low_volatility"
        else:
            vol_class = "normal_volatility"
        
        # Trend strength classification
        trend_strength = indicators.get('trend_strength', 0.5) if indicators else 0.5
        
        if "bull" in base_regime:
            if trend_strength > 0.7:
                return "strong_bull_trend"
            elif trend_strength > 0.4:
                return "bull_trend"
            else:
                return "weak_bull_trend"
        elif "bear" in base_regime:
            if trend_strength > 0.7:
                return "strong_bear_trend"
            elif trend_strength > 0.4:
                return "bear_trend"
            else:
                return "weak_bear_trend"
        elif "rang" in base_regime:
            if vol_class == "high_volatility":
                return "high_volatility_ranging"
            elif vol_class == "low_volatility":
                return "low_volatility_ranging"
            else:
                return "volatility_breakout"
        else:
            # Check for transition patterns
            if indicators and self._detect_regime_transition(indicators):
                return "trend_transition"
            else:
                return "bull_trend"  # Default fallback
    
    def _detect_regime_transition(self, indicators: Dict) -> bool:
        """
        Detect if market is in transition between regimes
        """
        try:
            # Check for mixed signals indicating transition
            trend_indicators = [
                indicators.get('ema_alignment', 0),
                indicators.get('adx', 25),
                indicators.get('momentum_score', 0)
            ]
            
            # High variance in trend indicators suggests transition
            if len(trend_indicators) > 1:
                indicator_variance = np.var(trend_indicators)
                return indicator_variance > 0.1  # Threshold for transition detection
            
            return False
        except:
            return False
    
    def _calculate_volatility_factor(self, volatility: float) -> Dict[str, float]:
        """
        Calculate strategy-specific volatility adjustment factors
        """
        if volatility > 0.04:  # High volatility
            return {
                'trend_following': 0.8,   # Reduce trend following
                'mean_reversion': 1.2,    # Increase mean reversion
                'breakout': 1.1,          # Slight increase for breakout
                'ml_prediction': 0.9      # Slight reduction for ML
            }
        elif volatility < 0.008:  # Low volatility
            return {
                'trend_following': 1.1,   # Increase trend following
                'mean_reversion': 0.8,    # Reduce mean reversion
                'breakout': 1.3,          # Increase breakout
                'ml_prediction': 1.0      # Neutral for ML
            }
        else:  # Normal volatility
            return {
                'trend_following': 1.0,
                'mean_reversion': 1.0,
                'breakout': 1.0,
                'ml_prediction': 1.0
            }
    
    def _calculate_trend_factor(self, trend_strength: float) -> Dict[str, float]:
        """
        Calculate strategy adjustment based on trend strength
        """
        if trend_strength > 0.7:  # Strong trend
            return {
                'trend_following': 1.3,
                'mean_reversion': 0.7,
                'breakout': 1.1,
                'ml_prediction': 1.0
            }
        elif trend_strength < 0.3:  # Weak trend
            return {
                'trend_following': 0.7,
                'mean_reversion': 1.3,
                'breakout': 0.9,
                'ml_prediction': 1.1
            }
        else:  # Moderate trend
            return {
                'trend_following': 1.0,
                'mean_reversion': 1.0,
                'breakout': 1.0,
                'ml_prediction': 1.0
            }
    
    def _enhanced_performance_adjustment(self, base_weights: Dict[str, float], 
                                       recent_performance: Dict, 
                                       market_regime: str) -> Dict[str, float]:
        """
        Advanced performance adjustment with regime-aware decay factors
        """
        if not recent_performance:
            return base_weights
        
        adjusted_weights = base_weights.copy()
        
        # Get comprehensive strategy performance
        strategy_performance = self._get_comprehensive_strategy_performance(market_regime)
        
        for strategy, performance in strategy_performance.items():
            if strategy in adjusted_weights and performance['reliable']:
                # Calculate multi-factor performance score
                performance_score = self._calculate_strategy_performance_score(performance, market_regime)
                
                # Apply performance-based adjustment
                adjustment_factor = self._performance_to_adjustment_factor(performance_score)
                adjusted_weights[strategy] *= adjustment_factor
        
        # Normalize weights
        total = sum(adjusted_weights.values())
        if total > 0:
            adjusted_weights = {k: v/total for k, v in adjusted_weights.items()}
        
        return adjusted_weights
    
    def _get_comprehensive_strategy_performance(self, market_regime: str, days: int = 30) -> Dict[str, Dict]:
        """
        Get comprehensive performance metrics for each strategy
        """
        try:
            if self.database:
                trades_df = self.database.get_historical_trades(days=days)
            else:
                trades_df = pd.DataFrame()
            
            strategy_performance = {}
            
            for strategy in ['trend_following', 'mean_reversion', 'breakout', 'ml_prediction']:
                strategy_trades = self._filter_trades_by_strategy(trades_df, strategy)
                
                if len(strategy_trades) >= self.min_trades_for_optimization[strategy]:
                    performance = self._calculate_strategy_performance_metrics(strategy_trades, market_regime)
                    performance['reliable'] = True
                else:
                    performance = self._get_default_performance(strategy)
                    performance['reliable'] = False
                
                strategy_performance[strategy] = performance
            
            return strategy_performance
            
        except Exception as e:
            self.logger.error(f"Error getting comprehensive performance: {e}")
            return self._get_default_performances()
    
    def _calculate_strategy_performance_metrics(self, trades_df: pd.DataFrame, 
                                             market_regime: str) -> Dict[str, Any]:
        """
        Calculate comprehensive performance metrics for a strategy
        """
        if trades_df.empty:
            return self._get_default_performance('unknown')
        
        winning_trades = trades_df[trades_df['pnl_percent'] > 0]
        losing_trades = trades_df[trades_df['pnl_percent'] < 0]
        
        # Basic metrics
        win_rate = (len(winning_trades) / len(trades_df)) * 100 if len(trades_df) > 0 else 0
        avg_win = winning_trades['pnl_percent'].mean() if len(winning_trades) > 0 else 0
        avg_loss = losing_trades['pnl_percent'].mean() if len(losing_trades) > 0 else 0
        total_pnl = trades_df['pnl_percent'].sum()
        
        # Risk-adjusted metrics
        sharpe_ratio = self._calculate_sharpe_ratio(trades_df['pnl_percent'])
        max_drawdown = self._calculate_max_drawdown(trades_df['pnl_percent'])
        profit_factor = abs(winning_trades['pnl_percent'].sum() / losing_trades['pnl_percent'].sum()) \
                       if len(losing_trades) > 0 and losing_trades['pnl_percent'].sum() != 0 else 0
        
        # Consistency metrics
        consistency_score = self._calculate_consistency_score(trades_df['pnl_percent'])
        recovery_factor = self._calculate_recovery_factor(trades_df['pnl_percent'])
        
        return {
            'trade_count': len(trades_df),
            'win_rate': win_rate,
            'avg_win': avg_win,
            'avg_loss': avg_loss,
            'total_pnl': total_pnl,
            'sharpe_ratio': sharpe_ratio,
            'max_drawdown': max_drawdown,
            'profit_factor': profit_factor,
            'consistency_score': consistency_score,
            'recovery_factor': recovery_factor,
            'best_trade': trades_df['pnl_percent'].max(),
            'worst_trade': trades_df['pnl_percent'].min(),
            'avg_trade_duration': self._calculate_avg_trade_duration(trades_df) if 'timestamp' in trades_df.columns else 0
        }
    
    def _calculate_sharpe_ratio(self, returns: pd.Series, risk_free_rate: float = 0.0) -> float:
        """Calculate Sharpe ratio for strategy returns"""
        if len(returns) < 2 or returns.std() == 0:
            return 0.0
        return (returns.mean() - risk_free_rate) / returns.std()
    
    def _calculate_max_drawdown(self, returns: pd.Series) -> float:
        """Calculate maximum drawdown"""
        cumulative = (1 + returns/100).cumprod()
        running_max = cumulative.expanding().max()
        drawdown = (cumulative - running_max) / running_max
        return abs(drawdown.min() * 100)  # Return as positive percentage
    
    def _calculate_consistency_score(self, returns: pd.Series) -> float:
        """Calculate consistency of returns (higher is better)"""
        if len(returns) < 2:
            return 0.0
        # Use inverse of coefficient of variation
        mean_return = returns.mean()
        std_return = returns.std()
        if mean_return == 0:
            return 0.0
        return mean_return / std_return if std_return > 0 else 1.0
    
    def _calculate_recovery_factor(self, returns: pd.Series) -> float:
        """Calculate recovery factor (total return / max drawdown)"""
        total_return = returns.sum()
        max_dd = self._calculate_max_drawdown(returns)
        return total_return / max_dd if max_dd > 0 else float('inf')
    
    def _calculate_avg_trade_duration(self, trades_df: pd.DataFrame) -> float:
        """Calculate average trade duration in hours"""
        if 'timestamp' not in trades_df.columns or len(trades_df) < 2:
            return 0.0
        
        try:
            durations = []
            for i in range(1, len(trades_df)):
                duration = (pd.to_datetime(trades_df.iloc[i]['timestamp']) - 
                          pd.to_datetime(trades_df.iloc[i-1]['timestamp'])).total_seconds() / 3600
                durations.append(duration)
            
            return np.mean(durations) if durations else 0.0
        except:
            return 0.0
    
    def _calculate_strategy_performance_score(self, performance: Dict, market_regime: str) -> float:
        """
        Calculate comprehensive performance score considering multiple factors
        """
        weights = {
            'win_rate': 0.25,
            'sharpe_ratio': 0.30,
            'profit_factor': 0.20,
            'consistency_score': 0.15,
            'recovery_factor': 0.10
        }
        
        # Normalize metrics
        normalized_metrics = {
            'win_rate': min(performance['win_rate'] / 100, 1.0),  # Convert to 0-1
            'sharpe_ratio': min(performance['sharpe_ratio'] / 2.0, 1.0),  # Cap at 2.0
            'profit_factor': min(performance['profit_factor'] / 3.0, 1.0),  # Cap at 3.0
            'consistency_score': min(performance['consistency_score'] / 2.0, 1.0),  # Cap at 2.0
            'recovery_factor': min(performance['recovery_factor'] / 5.0, 1.0)  # Cap at 5.0
        }
        
        # Calculate weighted score
        total_score = 0.0
        for metric, weight in weights.items():
            total_score += normalized_metrics[metric] * weight
        
        # Apply regime-specific adjustments
        regime_adjustment = self._get_regime_performance_adjustment(market_regime)
        total_score *= regime_adjustment
        
        return max(0.0, min(1.0, total_score))
    
    def _get_regime_performance_adjustment(self, market_regime: str) -> float:
        """
        Get performance adjustment factor based on market regime relevance
        """
        regime_adjustments = {
            'strong_bull_trend': 1.1,
            'bull_trend': 1.05,
            'weak_bull_trend': 1.0,
            'strong_bear_trend': 1.1,
            'bear_trend': 1.05,
            'weak_bear_trend': 1.0,
            'high_volatility_ranging': 0.9,
            'low_volatility_ranging': 0.95,
            'volatility_breakout': 1.0,
            'trend_transition': 0.85
        }
        return regime_adjustments.get(market_regime, 1.0)
    
    def _performance_to_adjustment_factor(self, performance_score: float) -> float:
        """
        Convert performance score to weight adjustment factor
        """
        # Map performance score (0-1) to adjustment factor (0.5-1.5)
        return 0.5 + performance_score
    
    def _apply_correlation_adjustment(self, weights: Dict[str, float], 
                                   correlation_matrix: pd.DataFrame) -> Dict[str, float]:
        """
        Adjust weights based on strategy correlations for better diversification
        """
        try:
            strategies = list(weights.keys())
            
            # Calculate portfolio concentration risk
            concentration_risk = sum(w**2 for w in weights.values())
            
            # If concentration is too high, diversify
            if concentration_risk > 0.4:  # Herfindahl index threshold
                # Reduce weights of highly correlated strategies
                for i, strat1 in enumerate(strategies):
                    for j, strat2 in enumerate(strategies):
                        if i < j and strat1 in correlation_matrix.columns and strat2 in correlation_matrix.index:
                            correlation = abs(correlation_matrix.loc[strat1, strat2])
                            if correlation > 0.7:  # High correlation threshold
                                # Reduce the lower performing strategy
                                if weights[strat1] > weights[strat2]:
                                    reduction = weights[strat2] * 0.1
                                    weights[strat2] -= reduction
                                else:
                                    reduction = weights[strat1] * 0.1
                                    weights[strat1] -= reduction
            
            # Normalize
            total = sum(weights.values())
            if total > 0:
                weights = {k: v/total for k, v in weights.items()}
            
            return weights
            
        except Exception as e:
            self.logger.error(f"Error in correlation adjustment: {e}")
            return weights
    
    def _enhanced_aggressiveness_adjustment(self, weights: Dict[str, float], 
                                          aggressiveness: str, 
                                          market_regime: str,
                                          volatility: float) -> Dict[str, float]:
        """
        Advanced aggressiveness adjustment with regime awareness
        """
        adjusted_weights = weights.copy()
        
        # Base aggressiveness factors
        aggressiveness_factors = {
            "conservative": {
                'trend_following': 1.1,
                'mean_reversion': 0.9,
                'breakout': 0.8,
                'ml_prediction': 1.0
            },
            "moderate": {
                'trend_following': 1.0,
                'mean_reversion': 1.0,
                'breakout': 1.0,
                'ml_prediction': 1.0
            },
            "aggressive": {
                'trend_following': 0.9,
                'mean_reversion': 1.1,
                'breakout': 1.2,
                'ml_prediction': 0.9
            },
            "high": {
                'trend_following': 0.8,
                'mean_reversion': 1.2,
                'breakout': 1.3,
                'ml_prediction': 0.7
            }
        }
        
        base_factors = aggressiveness_factors.get(aggressiveness, aggressiveness_factors["moderate"])
        
        # Volatility-based aggressiveness modulation
        volatility_modulation = self._calculate_volatility_aggressiveness_modulation(volatility)
        
        # Regime-based aggressiveness adjustment
        regime_modulation = self._calculate_regime_aggressiveness_modulation(market_regime)
        
        # Combine all factors
        for strategy in adjusted_weights:
            combined_factor = (
                base_factors[strategy] * 
                volatility_modulation[strategy] * 
                regime_modulation[strategy]
            )
            adjusted_weights[strategy] *= combined_factor
        
        # Normalize
        total = sum(adjusted_weights.values())
        if total > 0:
            adjusted_weights = {k: v/total for k, v in adjusted_weights.items()}
        
        return adjusted_weights
    
    def _calculate_volatility_aggressiveness_modulation(self, volatility: float) -> Dict[str, float]:
        """
        Modulate aggressiveness based on volatility conditions
        """
        if volatility > 0.04:  # High volatility - be more conservative
            return {
                'trend_following': 0.9,
                'mean_reversion': 1.1,
                'breakout': 0.8,
                'ml_prediction': 1.0
            }
        elif volatility < 0.008:  # Low volatility - can be more aggressive
            return {
                'trend_following': 1.1,
                'mean_reversion': 0.9,
                'breakout': 1.2,
                'ml_prediction': 1.0
            }
        else:
            return {
                'trend_following': 1.0,
                'mean_reversion': 1.0,
                'breakout': 1.0,
                'ml_prediction': 1.0
            }
    
    def _calculate_regime_aggressiveness_modulation(self, market_regime: str) -> Dict[str, float]:
        """
        Modulate aggressiveness based on market regime
        """
        regime_modulations = {
            'strong_bull_trend': {
                'trend_following': 1.2,
                'mean_reversion': 0.8,
                'breakout': 1.1,
                'ml_prediction': 1.0
            },
            'strong_bear_trend': {
                'trend_following': 1.1,
                'mean_reversion': 1.2,
                'breakout': 0.9,
                'ml_prediction': 1.0
            },
            'high_volatility_ranging': {
                'trend_following': 0.8,
                'mean_reversion': 1.3,
                'breakout': 0.9,
                'ml_prediction': 1.0
            },
            'trend_transition': {
                'trend_following': 0.7,
                'mean_reversion': 1.1,
                'breakout': 1.0,
                'ml_prediction': 1.2
            }
        }
        
        return regime_modulations.get(market_regime, {
            'trend_following': 1.0,
            'mean_reversion': 1.0,
            'breakout': 1.0,
            'ml_prediction': 1.0
        })
    
    def _apply_optimization_constraints(self, weights: Dict[str, float]) -> Dict[str, float]:
        """
        Apply optimization constraints to weights
        """
        constrained_weights = weights.copy()
        
        # Apply minimum and maximum weight constraints
        for strategy in constrained_weights:
            constrained_weights[strategy] = max(
                self.weight_constraints['min_weight'],
                min(
                    self.weight_constraints['max_weight'],
                    constrained_weights[strategy]
                )
            )
        
        # Limit maximum change from current weights if they exist
        if self.current_weights:
            for strategy in constrained_weights:
                if strategy in self.current_weights:
                    current_weight = self.current_weights[strategy]
                    max_change = self.weight_constraints['max_change_per_optimization']
                    constrained_weights[strategy] = max(
                        current_weight - max_change,
                        min(
                            current_weight + max_change,
                            constrained_weights[strategy]
                        )
                    )
        
        # Normalize to ensure sum = 1
        total = sum(constrained_weights.values())
        if total > 0:
            constrained_weights = {k: v/total for k, v in constrained_weights.items()}
        
        return constrained_weights
    
    def _calculate_optimization_score(self, weights: Dict[str, float], 
                                   performance: Dict) -> float:
        """
        Calculate a score for the optimization quality
        """
        try:
            # Factors for optimization score
            diversification_score = 1.0 - sum(w**2 for w in weights.values())  # Herfindahl index
            performance_alignment = self._calculate_performance_alignment(weights, performance)
            constraint_compliance = 1.0 if not self._check_constraints_violations(weights) else 0.5
            
            total_score = (
                diversification_score * 0.3 +
                performance_alignment * 0.5 +
                constraint_compliance * 0.2
            )
            
            return max(0.0, min(1.0, total_score))
        except:
            return 0.5
    
    def _calculate_performance_alignment(self, weights: Dict[str, float], 
                                      performance: Dict) -> float:
        """
        Calculate how well weights align with performance
        """
        try:
            # This is a simplified calculation - in practice, you'd use more sophisticated metrics
            strategy_performance = self._get_comprehensive_strategy_performance("current")
            
            alignment_score = 0.0
            total_weight = 0.0
            
            for strategy, weight in weights.items():
                if strategy in strategy_performance and strategy_performance[strategy]['reliable']:
                    perf_score = self._calculate_strategy_performance_score(
                        strategy_performance[strategy], "current"
                    )
                    alignment_score += weight * perf_score
                    total_weight += weight
            
            return alignment_score / total_weight if total_weight > 0 else 0.5
        except:
            return 0.5
    
    def _check_constraints_violations(self, weights: Dict[str, float]) -> bool:
        """
        Check if weight constraints are violated
        """
        try:
            # Check min/max constraints
            for strategy, weight in weights.items():
                if (weight < self.weight_constraints['min_weight'] or 
                    weight > self.weight_constraints['max_weight']):
                    return True
            
            # Check sum constraint
            total = sum(weights.values())
            if abs(total - 1.0) > 0.01:  # Allow small floating point errors
                return True
            
            return False
        except:
            return True
    
    def _get_fallback_weights(self, market_regime: str, aggressiveness: str) -> Dict[str, float]:
        """
        Get fallback weights when optimization fails
        """
        fallback_regimes = {
            "bull": "bull_trend",
            "bear": "bear_trend",
            "rang": "low_volatility_ranging"
        }
        
        # Find best matching regime
        for key, regime in fallback_regimes.items():
            if key in market_regime.lower():
                base_weights = self.regime_weights[regime].copy()
                break
        else:
            base_weights = self.regime_weights["bull_trend"].copy()
        
        # Apply basic aggressiveness adjustment
        aggressiveness_factors = {
            "conservative": 0.9,
            "moderate": 1.0,
            "aggressive": 1.1,
            "high": 1.2
        }
        
        factor = aggressiveness_factors.get(aggressiveness, 1.0)
        for strategy in base_weights:
            base_weights[strategy] *= factor
        
        # Normalize
        total = sum(base_weights.values())
        if total > 0:
            base_weights = {k: v/total for k, v in base_weights.items()}
        
        return base_weights
    
    def _filter_trades_by_strategy(self, trades_df: pd.DataFrame, strategy: str) -> pd.DataFrame:
        """
        Enhanced strategy classification for trades
        """
        if trades_df.empty:
            return pd.DataFrame()
        
        # Use multiple criteria to classify trades by strategy
        if strategy == 'trend_following':
            return trades_df[
                (trades_df['composite_score'] > 25) & 
                (trades_df['confidence'] > 65) &
                (trades_df.get('trend_strength', 50) > 60)
            ]
        elif strategy == 'mean_reversion':
            return trades_df[
                (trades_df['composite_score'].between(15, 35)) &
                (trades_df['confidence'] > 45) &
                (trades_df.get('rsi', 50).between(25, 75))
            ]
        elif strategy == 'breakout':
            return trades_df[
                (trades_df['composite_score'] > 20) &
                (trades_df['risk_reward_ratio'] > 1.8) &
                (trades_df.get('volatility', 0) > 0.01)
            ]
        elif strategy == 'ml_prediction':
            return trades_df[
                (trades_df['confidence'] > 55) &
                (trades_df.get('ml_confidence', 0) > 0.6)
            ]
        else:
            return pd.DataFrame()
    
    def _get_default_performance(self, strategy: str) -> Dict[str, Any]:
        """Get default performance metrics for a strategy"""
        return {
            'trade_count': 0,
            'win_rate': 50.0,
            'avg_win': 1.0,
            'avg_loss': -1.0,
            'total_pnl': 0.0,
            'sharpe_ratio': 0.0,
            'max_drawdown': 0.0,
            'profit_factor': 1.0,
            'consistency_score': 0.0,
            'recovery_factor': 0.0,
            'best_trade': 0.0,
            'worst_trade': 0.0,
            'avg_trade_duration': 0.0,
            'reliable': False
        }
    
    def _get_default_performances(self) -> Dict[str, Dict]:
        """Get default performances for all strategies"""
        return {
            'trend_following': self._get_default_performance('trend_following'),
            'mean_reversion': self._get_default_performance('mean_reversion'),
            'breakout': self._get_default_performance('breakout'),
            'ml_prediction': self._get_default_performance('ml_prediction')
        }
    
    def _store_optimization_record(self, record: Dict):
        """Store optimization record in database"""
        try:
            if self.database and hasattr(self.database, 'store_system_event'):
                self.database.store_system_event(
                    "STRATEGY_OPTIMIZATION",
                    record,
                    "INFO",
                    "Strategy Optimization"
                )
        except Exception as e:
            self.logger.warning(f"Failed to store optimization record: {e}")
    
    def analyze_market_regimes(self, symbol: str, historical_data: pd.DataFrame, 
                             technical_indicators: Dict = None) -> Dict:
        """
        Advanced market regime analysis with multiple timeframes and indicators
        """
        if len(historical_data) < 100:
            return {'regime': 'neutral', 'confidence': 0.5, 'regime_strength': 0.0}
        
        try:
            close_prices = historical_data['close'].astype(float)
            high_prices = historical_data['high'].astype(float)
            low_prices = historical_data['low'].astype(float)
            volume = historical_data['volume'].astype(float) if 'volume' in historical_data else None
            
            # Multi-timeframe analysis
            regime_scores = self._multi_timeframe_regime_analysis(
                close_prices, high_prices, low_prices, volume, technical_indicators
            )
            
            # Calculate regime probabilities
            regime_probabilities = self._calculate_regime_probabilities(regime_scores)
            
            # Determine dominant regime
            best_regime = max(regime_probabilities, key=regime_probabilities.get)
            confidence = regime_probabilities[best_regime]
            
            # Calculate regime strength
            regime_strength = self._calculate_regime_strength(close_prices, best_regime)
            
            # Volatility analysis
            volatility = self.calculate_volatility(historical_data)
            
            result = {
                'regime': best_regime,
                'confidence': confidence,
                'regime_strength': regime_strength,
                'probabilities': regime_probabilities,
                'volatility': volatility,
                'timestamp': datetime.now(),
                'multi_timeframe_alignment': self._calculate_timeframe_alignment(regime_scores)
            }
            
            self.market_regime = best_regime
            return result
            
        except Exception as e:
            self.logger.error(f"Failed to analyze market regime: {e}")
            return {'regime': 'neutral', 'confidence': 0.5, 'regime_strength': 0.0}
    
    def _multi_timeframe_regime_analysis(self, close: pd.Series, high: pd.Series, 
                                       low: pd.Series, volume: pd.Series = None,
                                       technical_indicators: Dict = None) -> Dict[str, Dict]:
        """
        Analyze market regime across multiple timeframes
        """
        timeframes = {
            'short_term': 20,
            'medium_term': 50,
            'long_term': 100
        }
        
        regime_scores = {}
        
        for timeframe, period in timeframes.items():
            if len(close) >= period:
                # Use last 'period' data points for this timeframe
                close_subset = close.iloc[-period:]
                high_subset = high.iloc[-period:]
                low_subset = low.iloc[-period:]
                
                regime_scores[timeframe] = self._single_timeframe_regime_analysis(
                    close_subset, high_subset, low_subset, timeframe
                )
        
        return regime_scores
    
    def _single_timeframe_regime_analysis(self, close: pd.Series, high: pd.Series, 
                                        low: pd.Series, timeframe: str) -> Dict[str, float]:
        """
        Analyze regime for a single timeframe
        """
        scores = {
            'bull_trend': 0.0,
            'bear_trend': 0.0,
            'ranging': 0.0
        }
        
        try:
            # Trend analysis
            sma_20 = close.rolling(20).mean()
            sma_50 = close.rolling(50).mean() if len(close) >= 50 else sma_20
            
            if len(sma_20) > 0 and len(sma_50) > 0:
                current_sma_20 = sma_20.iloc[-1]
                current_sma_50 = sma_50.iloc[-1]
                
                if current_sma_20 > current_sma_50:
                    scores['bull_trend'] += 0.4
                else:
                    scores['bear_trend'] += 0.4
            
            # Momentum analysis
            returns_5 = close.pct_change(5)
            returns_20 = close.pct_change(20)
            
            if len(returns_5) > 0 and len(returns_20) > 0:
                mom_5 = returns_5.iloc[-1]
                mom_20 = returns_20.iloc[-1]
                
                if mom_5 > 0.03 and mom_20 > 0.08:  # Strong upward momentum
                    scores['bull_trend'] += 0.3
                elif mom_5 < -0.03 and mom_20 < -0.08:  # Strong downward momentum
                    scores['bear_trend'] += 0.3
                elif abs(mom_5) < 0.01 and abs(mom_20) < 0.02:  # Low momentum
                    scores['ranging'] += 0.4
            
            # Volatility analysis for ranging markets
            volatility = close.pct_change().std()
            if volatility < 0.01:  # Low volatility suggests ranging
                scores['ranging'] += 0.3
            
            # Price action analysis
            price_range = (high.max() - low.min()) / close.mean()
            if price_range < 0.05:  # Small price range suggests ranging
                scores['ranging'] += 0.3
            
            # Normalize scores
            total = sum(scores.values())
            if total > 0:
                scores = {k: v/total for k, v in scores.items()}
            
            return scores
            
        except Exception as e:
            self.logger.warning(f"Error in single timeframe analysis ({timeframe}): {e}")
            return {'bull_trend': 0.33, 'bear_trend': 0.33, 'ranging': 0.34}
    
    def _calculate_regime_probabilities(self, regime_scores: Dict[str, Dict]) -> Dict[str, float]:
        """
        Calculate final regime probabilities from multi-timeframe scores
        """
        # Weight timeframes (long-term more important)
        timeframe_weights = {
            'short_term': 0.2,
            'medium_term': 0.3,
            'long_term': 0.5
        }
        
        final_scores = {'bull_trend': 0.0, 'bear_trend': 0.0, 'ranging': 0.0}
        
        for timeframe, scores in regime_scores.items():
            weight = timeframe_weights.get(timeframe, 0.2)
            for regime, score in scores.items():
                final_scores[regime] += score * weight
        
        # Normalize to probabilities
        total = sum(final_scores.values())
        if total > 0:
            final_scores = {k: v/total for k, v in final_scores.items()}
        
        return final_scores
    
    def _calculate_regime_strength(self, close_prices: pd.Series, regime: str) -> float:
        """
        Calculate the strength of the current regime
        """
        try:
            if len(close_prices) < 50:
                return 0.5
            
            # Use R-squared of price trend as strength indicator
            x = np.arange(len(close_prices))
            y = close_prices.values
            
            if len(y) < 2:
                return 0.5
            
            slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)
            r_squared = r_value ** 2
            
            # Adjust for regime type
            if regime == 'ranging':
                # For ranging markets, low R-squared indicates stronger ranging
                strength = 1.0 - r_squared
            else:
                # For trending markets, high R-squared indicates stronger trend
                strength = r_squared
            
            return max(0.0, min(1.0, strength))
            
        except:
            return 0.5
    
    def _calculate_timeframe_alignment(self, regime_scores: Dict[str, Dict]) -> float:
        """
        Calculate how well timeframes are aligned (higher is better)
        """
        if not regime_scores:
            return 0.0
        
        # Count how many timeframes agree on the primary regime
        primary_regimes = []
        for scores in regime_scores.values():
            primary_regime = max(scores, key=scores.get)
            primary_regimes.append(primary_regime)
        
        # Calculate alignment (proportion of timeframes with same primary regime)
        if len(primary_regimes) > 1:
            most_common = max(set(primary_regimes), key=primary_regimes.count)
            alignment = primary_regimes.count(most_common) / len(primary_regimes)
            return alignment
        else:
            return 1.0  # Single timeframe is always aligned with itself
    
    def calculate_volatility(self, historical_data: pd.DataFrame, period: int = 20) -> float:
        """
        Enhanced volatility calculation with multiple methods
        """
        if len(historical_data) < period:
            return 0.02
        
        try:
            close_prices = historical_data['close'].astype(float)
            high_prices = historical_data['high'].astype(float)
            low_prices = historical_data['low'].astype(float)
            
            # Method 1: Returns-based volatility
            returns = close_prices.pct_change().dropna()
            returns_volatility = returns.rolling(period).std().iloc[-1]
            
            # Method 2: ATR-based volatility
            tr1 = high_prices - low_prices
            tr2 = abs(high_prices - close_prices.shift())
            tr3 = abs(low_prices - close_prices.shift())
            tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
            atr = tr.rolling(period).mean().iloc[-1]
            atr_volatility = atr / close_prices.iloc[-1]
            
            # Method 3: Garman-Klass volatility estimator (more efficient)
            log_hl = np.log(high_prices / low_prices) ** 2
            log_co = np.log(close_prices / historical_data['open']) ** 2
            gk_volatility = np.sqrt(0.5 * log_hl.rolling(period).mean().iloc[-1] - 
                                  (2 * np.log(2) - 1) * log_co.rolling(period).mean().iloc[-1])
            
            # Combine methods (weighted average)
            combined_volatility = (
                returns_volatility * 0.5 +
                atr_volatility * 0.3 +
                gk_volatility * 0.2
            )
            
            # Annualize (assuming daily data)
            annualized_volatility = combined_volatility * np.sqrt(365)
            
            return annualized_volatility if not np.isnan(annualized_volatility) else 0.02
            
        except Exception as e:
            self.logger.error(f"Failed to calculate volatility: {e}")
            return 0.02
    
    def get_optimization_summary(self) -> Dict:
        """
        Get comprehensive optimization summary with analytics
        """
        recent_optimizations = self.optimization_history[-10:] if self.optimization_history else []
        
        # Calculate optimization performance
        optimization_performance = self._calculate_optimization_performance()
        
        # Get strategy performance summary
        strategy_performance = self._get_comprehensive_strategy_performance("current")
        
        summary = {
            'current_weights': self.current_weights,
            'market_regime': self.market_regime,
            'volatility_regime': self.volatility_regime,
            'optimization_performance': optimization_performance,
            'strategy_performance_summary': {
                strategy: {
                    'reliable': perf['reliable'],
                    'win_rate': perf['win_rate'],
                    'sharpe_ratio': perf['sharpe_ratio']
                }
                for strategy, perf in strategy_performance.items()
            },
            'recent_optimizations': [
                {
                    'timestamp': opt['timestamp'],
                    'market_regime': opt['market_regime'],
                    'optimization_score': opt['optimization_score']
                }
                for opt in recent_optimizations
            ],
            'optimization_count': len(self.optimization_history),
            'constraints_status': self._get_constraints_status(),
            'regime_stability': self._calculate_regime_stability()
        }
        
        return summary
    
    def _calculate_optimization_performance(self) -> Dict:
        """
        Calculate performance metrics for optimization history
        """
        if len(self.optimization_history) < 2:
            return {'score_trend': 'insufficient_data', 'average_score': 0.5}
        
        try:
            scores = [opt['optimization_score'] for opt in self.optimization_history]
            recent_scores = scores[-5:]  # Last 5 optimizations
            
            avg_score = np.mean(scores)
            recent_avg = np.mean(recent_scores)
            score_trend = "improving" if recent_avg > avg_score else "declining" if recent_avg < avg_score else "stable"
            
            return {
                'average_score': avg_score,
                'recent_average': recent_avg,
                'score_trend': score_trend,
                'score_std': np.std(scores),
                'best_score': max(scores),
                'worst_score': min(scores)
            }
        except:
            return {'score_trend': 'error', 'average_score': 0.5}
    
    def _get_constraints_status(self) -> Dict:
        """
        Get status of optimization constraints
        """
        if not self.current_weights:
            return {'status': 'no_weights', 'violations': []}
        
        violations = []
        
        # Check min/max constraints
        for strategy, weight in self.current_weights.items():
            if weight < self.weight_constraints['min_weight']:
                violations.append(f"{strategy}_below_min")
            if weight > self.weight_constraints['max_weight']:
                violations.append(f"{strategy}_above_max")
        
        # Check sum constraint
        total = sum(self.current_weights.values())
        if abs(total - 1.0) > 0.01:
            violations.append("weights_dont_sum_to_1")
        
        status = "valid" if not violations else "violations"
        
        return {
            'status': status,
            'violations': violations,
            'total_weight': total
        }
    
    def _calculate_regime_stability(self) -> float:
        """
        Calculate how stable the market regime has been
        """
        if len(self.optimization_history) < 5:
            return 0.5
        
        try:
            recent_regimes = [opt['market_regime'] for opt in self.optimization_history[-5:]]
            # Count regime changes
            changes = 0
            for i in range(1, len(recent_regimes)):
                if recent_regimes[i] != recent_regimes[i-1]:
                    changes += 1
            
            stability = 1.0 - (changes / (len(recent_regimes) - 1))
            return max(0.0, min(1.0, stability))
        except:
            return 0.5
    
    def optimize_parameters(self, symbol: str, historical_data: pd.DataFrame, 
                          market_regime: str = None) -> Dict:
        """
        Advanced parameter optimization for specific symbol and market conditions
        """
        if len(historical_data) < 100:
            return {}
        
        try:
            # Analyze symbol-specific characteristics
            volatility = self.calculate_volatility(historical_data)
            if market_regime is None:
                regime_analysis = self.analyze_market_regimes(symbol, historical_data)
                market_regime = regime_analysis['regime']
            
            # Get symbol-specific performance if available
            symbol_performance = self._get_symbol_performance(symbol)
            
            # Optimize parameters using multiple methods
            optimized_params = {
                'confidence_threshold': self._optimize_confidence_threshold(volatility, market_regime, symbol_performance),
                'position_size_multiplier': self._optimize_position_size(volatility, market_regime, symbol_performance),
                'stop_loss_multiplier': self._optimize_stop_loss(volatility, market_regime, symbol_performance),
                'take_profit_multiplier': self._optimize_take_profit(volatility, market_regime, symbol_performance),
                'reentry_delay': self._optimize_reentry_delay(symbol_performance),
                'trailing_stop_activation': self._optimize_trailing_stop_activation(volatility, market_regime)
            }
            
            self.logger.info(f"Advanced parameters optimized for {symbol}: {optimized_params}")
            
            # Store parameter optimization
            if self.database:
                self._store_parameter_optimization(symbol, optimized_params, market_regime, volatility)
            
            return optimized_params
            
        except Exception as e:
            self.logger.error(f"Failed to optimize parameters for {symbol}: {e}")
            return self._get_default_parameters()
    
    def _get_symbol_performance(self, symbol: str) -> Dict:
        """
        Get symbol-specific performance metrics
        """
        try:
            if self.database:
                symbol_trades = self.database.get_symbol_trades(symbol, days=30)
                if not symbol_trades.empty:
                    return self._calculate_strategy_performance_metrics(symbol_trades, "symbol_specific")
            return {}
        except:
            return {}
    
    def _optimize_confidence_threshold(self, volatility: float, market_regime: str, 
                                     symbol_performance: Dict) -> float:
        """
        Optimize confidence threshold based on multiple factors
        """
        base_threshold = 25.0
        
        # Volatility adjustment
        volatility_adjustment = max(0, (volatility - 0.02) * 400)  # More sensitive adjustment
        
        # Regime adjustment
        regime_adjustments = {
            'strong_bull_trend': -5.0,
            'bull_trend': -2.5,
            'weak_bull_trend': 0.0,
            'strong_bear_trend': 5.0,
            'bear_trend': 2.5,
            'weak_bear_trend': 0.0,
            'high_volatility_ranging': 7.5,
            'low_volatility_ranging': -2.5,
            'volatility_breakout': 0.0,
            'trend_transition': 10.0
        }
        regime_adjustment = regime_adjustments.get(market_regime, 0.0)
        
        # Performance-based adjustment
        performance_adjustment = 0.0
        if symbol_performance and 'win_rate' in symbol_performance:
            if symbol_performance['win_rate'] > 70:
                performance_adjustment = -7.5  # Lower threshold for high win rate
            elif symbol_performance['win_rate'] < 40:
                performance_adjustment = 10.0  # Higher threshold for low win rate
        
        optimized_threshold = base_threshold + volatility_adjustment + regime_adjustment + performance_adjustment
        
        return max(10.0, min(50.0, optimized_threshold))
    
    def _optimize_position_size(self, volatility: float, market_regime: str, 
                              symbol_performance: Dict) -> float:
        """
        Optimize position size multiplier
        """
        base_multiplier = 1.0
        
        # Volatility-based adjustment
        if volatility > 0.04:
            base_multiplier *= 0.6  # 40% reduction
        elif volatility > 0.03:
            base_multiplier *= 0.8  # 20% reduction
        elif volatility < 0.008:
            base_multiplier *= 1.3  # 30% increase
        
        # Regime-based adjustment
        if "bear" in market_regime or "high_volatility" in market_regime:
            base_multiplier *= 0.8  # Additional reduction in risky conditions
        
        # Performance-based adjustment
        if symbol_performance and 'sharpe_ratio' in symbol_performance:
            if symbol_performance['sharpe_ratio'] > 1.5:
                base_multiplier *= 1.2  # Increase for good risk-adjusted returns
            elif symbol_performance['sharpe_ratio'] < 0.5:
                base_multiplier *= 0.8  # Decrease for poor risk-adjusted returns
        
        return max(0.3, min(2.0, base_multiplier))
    
    def _optimize_stop_loss(self, volatility: float, market_regime: str, 
                          symbol_performance: Dict) -> float:
        """
        Optimize stop loss multiplier
        """
        base_multiplier = 1.0
        
        # Volatility-based adjustment (wider stops in high volatility)
        if volatility > 0.04:
            base_multiplier *= 1.4
        elif volatility > 0.03:
            base_multiplier *= 1.2
        elif volatility < 0.008:
            base_multiplier *= 0.7  # Tighter stops in low volatility
        
        # Regime-based adjustment
        if "trend" in market_regime:
            base_multiplier *= 1.1  # Wider stops in trending markets
        elif "rang" in market_regime:
            base_multiplier *= 0.9  # Tighter stops in ranging markets
        
        return max(0.5, min(2.0, base_multiplier))
    
    def _optimize_take_profit(self, volatility: float, market_regime: str, 
                            symbol_performance: Dict) -> float:
        """
        Optimize take profit multiplier
        """
        base_multiplier = 1.0
        
        # Volatility-based adjustment
        if volatility > 0.04:
            base_multiplier *= 1.3  # Wider targets in high volatility
        elif volatility < 0.008:
            base_multiplier *= 0.8  # Tighter targets in low volatility
        
        # Regime-based adjustment
        if "bull" in market_regime:
            base_multiplier *= 1.2  # Let profits run in bull markets
        elif "bear" in market_regime:
            base_multiplier *= 0.9  # Take profits quicker in bear markets
        
        # Performance-based adjustment
        if symbol_performance and 'profit_factor' in symbol_performance:
            if symbol_performance['profit_factor'] > 2.0:
                base_multiplier *= 1.1  # Slightly wider targets for profitable strategies
        
        return max(0.5, min(2.0, base_multiplier))
    
    def _optimize_reentry_delay(self, symbol_performance: Dict) -> int:
        """
        Optimize reentry delay (in minutes) after stopped out
        """
        base_delay = 30  # minutes
        
        if symbol_performance and 'avg_trade_duration' in symbol_performance:
            avg_duration = symbol_performance['avg_trade_duration']
            if avg_duration > 4:  # hours
                base_delay = 60  # Longer delay for longer-term trades
            elif avg_duration < 1:
                base_delay = 15  # Shorter delay for shorter-term trades
        
        return base_delay
    
    def _optimize_trailing_stop_activation(self, volatility: float, market_regime: str) -> float:
        """
        Optimize trailing stop activation threshold (as percentage of profit)
        """
        base_activation = 0.02  # 2% profit
        
        # Higher volatility -> activate trailing stops earlier
        if volatility > 0.04:
            base_activation = 0.015  # 1.5%
        elif volatility < 0.008:
            base_activation = 0.03  # 3%
        
        # In trending markets, allow more room for profits
        if "trend" in market_regime:
            base_activation = max(base_activation, 0.025)
        
        return base_activation
    
    def _get_default_parameters(self) -> Dict:
        """
        Get default parameters as fallback
        """
        return {
            'confidence_threshold': 25.0,
            'position_size_multiplier': 1.0,
            'stop_loss_multiplier': 1.0,
            'take_profit_multiplier': 1.0,
            'reentry_delay': 30,
            'trailing_stop_activation': 0.02
        }
    
    def _store_parameter_optimization(self, symbol: str, parameters: Dict, 
                                    market_regime: str, volatility: float):
        """
        Store parameter optimization record
        """
        try:
            if self.database and hasattr(self.database, 'store_system_event'):
                record = {
                    'symbol': symbol,
                    'parameters': parameters,
                    'market_regime': market_regime,
                    'volatility': volatility,
                    'timestamp': datetime.now()
                }
                self.database.store_system_event(
                    "PARAMETER_OPTIMIZATION",
                    record,
                    "INFO",
                    "Strategy Optimization"
                )
        except Exception as e:
            self.logger.warning(f"Failed to store parameter optimization: {e}")
    
    def get_performance_analytics(self, days: int = 30) -> Dict:
        """
        Get comprehensive performance analytics with advanced metrics
        """
        try:
            if self.database:
                trades_df = self.database.get_historical_trades(days=days)
            else:
                trades_df = pd.DataFrame()
            
            if trades_df.empty:
                return {'error': 'No trade data available', 'period': days}
            
            analytics = {
                'period': f"last_{days}_days",
                'summary': self._calculate_enhanced_performance_summary(trades_df),
                'strategy_performance': self._get_comprehensive_strategy_performance("analytics", days),
                'time_based_analysis': self._analyze_enhanced_time_performance(trades_df),
                'symbol_analysis': self._analyze_enhanced_symbol_performance(trades_df),
                'regime_performance': self._analyze_regime_performance(trades_df),
                'risk_metrics': self._calculate_risk_metrics(trades_df),
                'performance_trends': self._analyze_performance_trends(days)
            }
            
            return analytics
            
        except Exception as e:
            self.logger.error(f"Failed to generate performance analytics: {e}")
            return {'error': str(e), 'period': days}
    
    def _calculate_enhanced_performance_summary(self, trades_df: pd.DataFrame) -> Dict:
        """
        Calculate enhanced performance summary with additional metrics
        """
        if trades_df.empty:
            return {}
        
        winning_trades = trades_df[trades_df['pnl_percent'] > 0]
        losing_trades = trades_df[trades_df['pnl_percent'] < 0]
        breakeven_trades = trades_df[trades_df['pnl_percent'] == 0]
        
        # Basic metrics
        total_trades = len(trades_df)
        winning_count = len(winning_trades)
        losing_count = len(losing_trades)
        breakeven_count = len(breakeven_trades)
        
        win_rate = (winning_count / total_trades) * 100 if total_trades > 0 else 0
        loss_rate = (losing_count / total_trades) * 100 if total_trades > 0 else 0
        
        # Advanced metrics
        sharpe_ratio = self._calculate_sharpe_ratio(trades_df['pnl_percent'])
        max_drawdown = self._calculate_max_drawdown(trades_df['pnl_percent'])
        calmar_ratio = trades_df['pnl_percent'].sum() / max_drawdown if max_drawdown > 0 else 0
        profit_factor = abs(winning_trades['pnl_percent'].sum() / losing_trades['pnl_percent'].sum()) \
                       if losing_count > 0 and losing_trades['pnl_percent'].sum() != 0 else float('inf')
        
        # Consistency metrics
        monthly_returns = self._calculate_monthly_returns(trades_df)
        consistency = np.std(monthly_returns) if len(monthly_returns) > 1 else 0
        
        # Trade duration metrics
        avg_trade_duration = self._calculate_avg_trade_duration(trades_df)
        
        return {
            'total_trades': total_trades,
            'winning_trades': winning_count,
            'losing_trades': losing_count,
            'breakeven_trades': breakeven_count,
            'win_rate': win_rate,
            'loss_rate': loss_rate,
            'avg_win': winning_trades['pnl_percent'].mean() if winning_count > 0 else 0,
            'avg_loss': losing_trades['pnl_percent'].mean() if losing_count > 0 else 0,
            'largest_win': winning_trades['pnl_percent'].max() if winning_count > 0 else 0,
            'largest_loss': losing_trades['pnl_percent'].min() if losing_count > 0 else 0,
            'total_pnl_percent': trades_df['pnl_percent'].sum(),
            'sharpe_ratio': sharpe_ratio,
            'max_drawdown': max_drawdown,
            'calmar_ratio': calmar_ratio,
            'profit_factor': profit_factor,
            'consistency': consistency,
            'avg_trade_duration_hours': avg_trade_duration,
            'trades_per_day': total_trades / 30 if total_trades > 0 else 0  # Assuming 30 days
        }
    
    def _calculate_monthly_returns(self, trades_df: pd.DataFrame) -> List[float]:
        """
        Calculate monthly returns for consistency analysis
        """
        try:
            if 'timestamp' not in trades_df.columns:
                return []
            
            trades_df = trades_df.copy()
            trades_df['timestamp'] = pd.to_datetime(trades_df['timestamp'])
            trades_df['month'] = trades_df['timestamp'].dt.to_period('M')
            
            monthly_returns = trades_df.groupby('month')['pnl_percent'].sum().tolist()
            return monthly_returns
        except:
            return []
    
    def _analyze_enhanced_time_performance(self, trades_df: pd.DataFrame) -> Dict:
        """
        Enhanced time-based performance analysis
        """
        if trades_df.empty or 'timestamp' not in trades_df.columns:
            return {}
        
        try:
            trades_df = trades_df.copy()
            trades_df['timestamp'] = pd.to_datetime(trades_df['timestamp'])
            trades_df['hour'] = trades_df['timestamp'].dt.hour
            trades_df['day_of_week'] = trades_df['timestamp'].dt.day_name()
            trades_df['week_of_month'] = (trades_df['timestamp'].dt.day - 1) // 7 + 1
            
            hour_performance = trades_df.groupby('hour')['pnl_percent'].agg([
                'mean', 'count', 'std', 'sum'
            ]).to_dict()
            
            day_performance = trades_df.groupby('day_of_week')['pnl_percent'].agg([
                'mean', 'count', 'std', 'sum'
            ]).to_dict()
            
            week_performance = trades_df.groupby('week_of_month')['pnl_percent'].agg([
                'mean', 'count', 'std', 'sum'
            ]).to_dict()
            
            return {
                'by_hour': hour_performance,
                'by_day': day_performance,
                'by_week_of_month': week_performance,
                'best_performing_hour': self._find_best_performing_time(hour_performance),
                'best_performing_day': self._find_best_performing_time(day_performance)
            }
        except Exception as e:
            self.logger.error(f"Error in enhanced time analysis: {e}")
            return {}
    
    def _find_best_performing_time(self, performance_dict: Dict) -> Dict:
        """
        Find the best performing time period
        """
        try:
            if 'mean' not in performance_dict or not performance_dict['mean']:
                return {}
            
            best_period = max(performance_dict['mean'], key=performance_dict['mean'].get)
            return {
                'period': best_period,
                'avg_pnl': performance_dict['mean'][best_period],
                'trade_count': performance_dict['count'][best_period],
                'total_pnl': performance_dict['sum'][best_period]
            }
        except:
            return {}
    
    def _analyze_enhanced_symbol_performance(self, trades_df: pd.DataFrame) -> Dict:
        """
        Enhanced symbol performance analysis
        """
        if trades_df.empty or 'symbol' not in trades_df.columns:
            return {}
        
        symbol_stats = {}
        
        for symbol in trades_df['symbol'].unique():
            symbol_trades = trades_df[trades_df['symbol'] == symbol]
            winning = symbol_trades[symbol_trades['pnl_percent'] > 0]
            losing = symbol_trades[symbol_trades['pnl_percent'] < 0]
            
            # Calculate comprehensive metrics
            sharpe = self._calculate_sharpe_ratio(symbol_trades['pnl_percent'])
            max_dd = self._calculate_max_drawdown(symbol_trades['pnl_percent'])
            
            symbol_stats[symbol] = {
                'trade_count': len(symbol_trades),
                'win_rate': (len(winning) / len(symbol_trades)) * 100,
                'loss_rate': (len(losing) / len(symbol_trades)) * 100,
                'avg_pnl': symbol_trades['pnl_percent'].mean(),
                'total_pnl': symbol_trades['pnl_percent'].sum(),
                'best_trade': symbol_trades['pnl_percent'].max(),
                'worst_trade': symbol_trades['pnl_percent'].min(),
                'sharpe_ratio': sharpe,
                'max_drawdown': max_dd,
                'profit_factor': abs(winning['pnl_percent'].sum() / losing['pnl_percent'].sum()) 
                               if len(losing) > 0 and losing['pnl_percent'].sum() != 0 else float('inf'),
                'consistency': symbol_trades['pnl_percent'].std() / abs(symbol_trades['pnl_percent'].mean()) 
                             if symbol_trades['pnl_percent'].mean() != 0 else 0
            }
        
        return symbol_stats
    
    def _analyze_regime_performance(self, trades_df: pd.DataFrame) -> Dict:
        """
        Analyze performance by market regime (if regime data is available)
        """
        if trades_df.empty or 'market_regime' not in trades_df.columns:
            return {'error': 'No regime data available'}
        
        regime_stats = {}
        
        for regime in trades_df['market_regime'].unique():
            regime_trades = trades_df[trades_df['market_regime'] == regime]
            winning = regime_trades[regime_trades['pnl_percent'] > 0]
            
            regime_stats[regime] = {
                'trade_count': len(regime_trades),
                'win_rate': (len(winning) / len(regime_trades)) * 100,
                'avg_pnl': regime_trades['pnl_percent'].mean(),
                'total_pnl': regime_trades['pnl_percent'].sum(),
                'best_trade': regime_trades['pnl_percent'].max(),
                'worst_trade': regime_trades['pnl_percent'].min()
            }
        
        return regime_stats
    
    def _calculate_risk_metrics(self, trades_df: pd.DataFrame) -> Dict:
        """
        Calculate comprehensive risk metrics
        """
        if trades_df.empty:
            return {}
        
        returns = trades_df['pnl_percent']
        
        return {
            'volatility': returns.std(),
            'value_at_risk_95': np.percentile(returns, 5),
            'expected_shortfall_95': returns[returns <= np.percentile(returns, 5)].mean(),
            'skewness': stats.skew(returns) if len(returns) > 2 else 0,
            'kurtosis': stats.kurtosis(returns) if len(returns) > 3 else 0,
            'var_ratio': self._calculate_variance_ratio(returns),
            'hurst_exponent': self._calculate_hurst_exponent(returns)
        }
    
    def _calculate_variance_ratio(self, returns: pd.Series) -> float:
        """
        Calculate variance ratio test for random walk (efficiency test)
        """
        try:
            if len(returns) < 10:
                return 1.0
            
            # Simple implementation - in practice, use more sophisticated methods
            var_1 = returns.var()
            var_2 = returns.rolling(2).sum().var()
            
            if var_1 == 0:
                return 1.0
            
            return var_2 / (2 * var_1)
        except:
            return 1.0
    
    def _calculate_hurst_exponent(self, returns: pd.Series) -> float:
        """
        Calculate Hurst exponent for market efficiency measurement
        """
        try:
            if len(returns) < 50:
                return 0.5
            
            lags = range(2, 20)
            tau = [np.std(np.subtract(returns[lag:].values, returns[:-lag].values)) for lag in lags]
            poly = np.polyfit(np.log(lags), np.log(tau), 1)
            return poly[0]
        except:
            return 0.5
    
    def _analyze_performance_trends(self, days: int) -> Dict:
        """
        Analyze performance trends over time
        """
        try:
            if not self.database or len(self.optimization_history) < 5:
                return {'trend': 'insufficient_data'}
            
            # Get recent optimization scores
            recent_scores = [opt['optimization_score'] for opt in self.optimization_history[-10:]]
            
            if len(recent_scores) < 3:
                return {'trend': 'insufficient_data'}
            
            # Calculate trend
            x = np.arange(len(recent_scores))
            slope, _, r_value, _, _ = stats.linregress(x, recent_scores)
            
            trend_direction = "improving" if slope > 0.01 else "declining" if slope < -0.01 else "stable"
            trend_strength = abs(r_value)
            
            return {
                'trend_direction': trend_direction,
                'trend_strength': trend_strength,
                'recent_scores': recent_scores,
                'slope': slope
            }
        except:
            return {'trend': 'error'}


# Backward compatibility
class StrategyOptimizer(AdvancedStrategyOptimizer):
    """
    Legacy StrategyOptimizer class for backward compatibility
    """
    def __init__(self, trading_database=None):
        super().__init__(trading_database)
        print("🔧 Legacy StrategyOptimizer initialized (using AdvancedStrategyOptimizer)")


# Example usage and testing
if __name__ == "__main__":
    # Mock database for testing
    class MockDatabase:
        def get_historical_trades(self, days):
            # Return mock trade data
            return pd.DataFrame({
                'symbol': ['BTCUSDT', 'ETHUSDT', 'BTCUSDT', 'ETHUSDT', 'ADAUSDT'],
                'timestamp': [datetime.now() - timedelta(hours=i) for i in range(5)],
                'action': ['BUY', 'SELL', 'BUY', 'SELL', 'BUY'],
                'pnl_percent': [2.5, -1.2, 3.1, 0.8, -0.5],
                'composite_score': [25, 18, 30, 22, 15],
                'confidence': [65, 55, 70, 60, 45],
                'success': [True, True, True, True, False],
                'risk_reward_ratio': [2.1, 1.8, 2.5, 2.0, 1.5],
                'market_regime': ['bull_trend', 'bear_trend', 'bull_trend', 'ranging', 'bear_trend'],
                'trend_strength': [70, 30, 80, 40, 25],
                'rsi': [65, 35, 70, 45, 30],
                'volatility': [0.025, 0.035, 0.022, 0.028, 0.040],
                'ml_confidence': [0.7, 0.6, 0.8, 0.5, 0.4]
            })
        
        def get_symbol_trades(self, symbol, days):
            return self.get_historical_trades(days)
        
        def store_system_event(self, event_type, data, level, category):
            print(f"📊 Storing event: {event_type} - {level}")
    
    # Test the enhanced optimizer
    db = MockDatabase()
    optimizer = AdvancedStrategyOptimizer(db)
    
    # Test optimization with various parameters
    weights = optimizer.optimize_weights(
        market_regime="bull_trend",
        volatility=0.025,
        recent_performance={'win_rate': 65, 'avg_pnl': 1.5, 'sharpe_ratio': 1.2},
        aggressiveness="moderate",
        market_indicators={'trend_strength': 0.7, 'adx': 45}
    )
    
    print(f"🎯 Optimized weights: {weights}")
    
    # Test market regime analysis
    mock_data = pd.DataFrame({
        'close': np.cumsum(np.random.randn(100) * 0.01) + 100,
        'high': np.cumsum(np.random.randn(100) * 0.01) + 101,
        'low': np.cumsum(np.random.randn(100) * 0.01) + 99,
        'open': np.cumsum(np.random.randn(100) * 0.01) + 100,
        'volume': np.random.randn(100) * 1000 + 10000
    })
    
    regime = optimizer.analyze_market_regimes("BTCUSDT", mock_data)
    print(f"📈 Market regime analysis: {regime}")
    
    # Test parameter optimization
    params = optimizer.optimize_parameters("BTCUSDT", mock_data)
    print(f"⚙️ Optimized parameters: {params}")
    
    # Test performance analytics
    analytics = optimizer.get_performance_analytics(days=7)
    print(f"📊 Performance analytics keys: {analytics.keys()}")
    
    # Test optimization summary
    summary = optimizer.get_optimization_summary()
    print(f"📋 Optimization summary: {summary.keys()}")